// Trap hazards found in dungeon combat rooms
export const TrapType = {
  SPIKES: 'spikes',
  FLAME: 'flame',
  SAWBLADE: 'sawblade'
};

export class SpikeTrap {
  constructor(x, y, width = 52, height = 52) {
    this.type = TrapType.SPIKES;
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;

    // States: 'RETRACTED' -> 'WARNING' -> 'EXTENDED'
    this.state = 'RETRACTED';
    this.retractedTime = 2.2 + Math.random() * 0.8;
    this.warningTime = 0.6;
    this.extendedTime = 1.3;
    this.timer = Math.random() * this.retractedTime; // Desynchronize traps

    this.rattleOffset = 0;
  }

  update(dt, player, particles, audio) {
    this.timer += dt;

    if (this.state === 'RETRACTED') {
      if (this.timer >= this.retractedTime) {
        this.state = 'WARNING';
        this.timer = 0;
      }
    } else if (this.state === 'WARNING') {
      // Rapid rattle shake effect
      this.rattleOffset = (Math.random() - 0.5) * 3;
      if (this.timer >= this.warningTime) {
        this.state = 'EXTENDED';
        this.timer = 0;
        this.rattleOffset = 0;
        if (particles) {
          particles.createDust(this.x + this.width / 2, this.y + this.height / 2, 6);
        }
      }
    } else if (this.state === 'EXTENDED') {
      if (this.timer >= this.extendedTime) {
        this.state = 'RETRACTED';
        this.timer = 0;
      }
    }
  }

  isActiveHazardAt(px, py, pradius = 16) {
    if (this.state !== 'EXTENDED') return false;
    // Check circle vs rectangle intersection
    const closestX = Math.max(this.x, Math.min(px, this.x + this.width));
    const closestY = Math.max(this.y, Math.min(py, this.y + this.height));
    const distX = px - closestX;
    const distY = py - closestY;
    return (distX * distX + distY * distY) < (pradius * pradius);
  }

  render(ctx) {
    ctx.save();
    ctx.translate(this.x + this.rattleOffset, this.y);

    // Stone base plate
    ctx.fillStyle = '#1e222d';
    ctx.fillRect(0, 0, this.width, this.height);

    // Iron border
    ctx.strokeStyle = this.state === 'WARNING' ? '#f59e0b' : '#334155';
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, this.width, this.height);

    const cols = 3;
    const rows = 3;
    const cellW = this.width / cols;
    const cellH = this.height / rows;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const cx = c * cellW + cellW / 2;
        const cy = r * cellH + cellH / 2;

        if (this.state === 'RETRACTED') {
          // Hole in the grate
          ctx.fillStyle = '#0a0d14';
          ctx.beginPath();
          ctx.arc(cx, cy, 4, 0, Math.PI * 2);
          ctx.fill();
        } else if (this.state === 'WARNING') {
          // Warning: spike tip peeking through hole
          ctx.fillStyle = '#0a0d14';
          ctx.beginPath();
          ctx.arc(cx, cy, 4, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#f59e0b';
          ctx.beginPath();
          ctx.arc(cx, cy, 2, 0, Math.PI * 2);
          ctx.fill();
        } else if (this.state === 'EXTENDED') {
          // Extended deadly steel spike pyramid
          ctx.fillStyle = '#475569';
          ctx.beginPath();
          ctx.moveTo(cx - 6, cy + 6);
          ctx.lineTo(cx, cy - 10);
          ctx.lineTo(cx + 6, cy + 6);
          ctx.closePath();
          ctx.fill();

          // Gleam
          ctx.fillStyle = '#f8fafc';
          ctx.beginPath();
          ctx.moveTo(cx - 2, cy + 6);
          ctx.lineTo(cx, cy - 10);
          ctx.lineTo(cx + 1, cy + 6);
          ctx.closePath();
          ctx.fill();

          // Blood tip tint
          ctx.fillStyle = '#ef4444';
          ctx.beginPath();
          ctx.arc(cx, cy - 10, 1.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    ctx.restore();
  }
}

export class FlameVent {
  constructor(x, y, radius = 22) {
    this.type = TrapType.FLAME;
    this.x = x;
    this.y = y;
    this.radius = radius;

    // States: 'IDLE' -> 'WARNING' -> 'ERUPTING'
    this.state = 'IDLE';
    this.idleTime = 2.8 + Math.random() * 1.0;
    this.warningTime = 0.7;
    this.eruptingTime = 1.4;
    this.timer = Math.random() * this.idleTime;

    this.flameAnim = 0;
  }

  update(dt, player, particles, audio) {
    this.timer += dt;
    this.flameAnim += dt * 14;

    if (this.state === 'IDLE') {
      if (this.timer >= this.idleTime) {
        this.state = 'WARNING';
        this.timer = 0;
      }
    } else if (this.state === 'WARNING') {
      // Sparks and smoke puff
      if (particles && Math.random() < 0.25) {
        particles.createDust(this.x, this.y, 2);
      }
      if (this.timer >= this.warningTime) {
        this.state = 'ERUPTING';
        this.timer = 0;
        if (particles) {
          particles.createExplosion(this.x, this.y, 18);
        }
      }
    } else if (this.state === 'ERUPTING') {
      if (particles && Math.random() < 0.4) {
        particles.createHitSparks(this.x + (Math.random() - 0.5) * 20, this.y + (Math.random() - 0.5) * 20, '#ff4400');
      }
      if (this.timer >= this.eruptingTime) {
        this.state = 'IDLE';
        this.timer = 0;
      }
    }
  }

  isActiveHazardAt(px, py, pradius = 16) {
    if (this.state !== 'ERUPTING') return false;
    const dist = Math.hypot(px - this.x, py - this.y);
    return dist < (this.radius + pradius);
  }

  render(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);

    // Bronze circular vent plate
    ctx.fillStyle = '#291b10';
    ctx.beginPath();
    ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Grate slits
    ctx.strokeStyle = '#0a0502';
    ctx.lineWidth = 2.5;
    for (let i = -this.radius + 6; i <= this.radius - 6; i += 7) {
      const halfLen = Math.sqrt(Math.max(0, this.radius * this.radius - i * i)) - 4;
      ctx.beginPath();
      ctx.moveTo(-halfLen, i);
      ctx.lineTo(halfLen, i);
      ctx.stroke();
    }

    if (this.state === 'IDLE') {
      // Deep glowing ember inside
      ctx.fillStyle = 'rgba(234, 88, 12, 0.25)';
      ctx.beginPath();
      ctx.arc(0, 0, this.radius * 0.6, 0, Math.PI * 2);
      ctx.fill();
    } else if (this.state === 'WARNING') {
      // Pulsing bright warning glow
      const pulse = Math.sin(this.flameAnim * 0.8) * 0.3 + 0.7;
      ctx.fillStyle = `rgba(249, 115, 22, ${pulse * 0.6})`;
      ctx.shadowBlur = 15;
      ctx.shadowColor = '#ea580c';
      ctx.beginPath();
      ctx.arc(0, 0, this.radius * 0.85, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    } else if (this.state === 'ERUPTING') {
      // Roaring fire pillar
      const fRadius = this.radius * (1.1 + Math.sin(this.flameAnim) * 0.2);

      const grad = ctx.createRadialGradient(0, 0, 4, 0, 0, fRadius);
      grad.addColorStop(0, '#ffffff');
      grad.addColorStop(0.3, '#facc15');
      grad.addColorStop(0.7, '#f97316');
      grad.addColorStop(1, 'rgba(220, 38, 38, 0)');

      ctx.shadowBlur = 24;
      ctx.shadowColor = '#f97316';
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(0, 0, fRadius, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    ctx.restore();
  }
}

export class SawbladeTrap {
  constructor(x1, y1, x2, y2, speed = 130) {
    this.type = TrapType.SAWBLADE;
    this.x1 = x1;
    this.y1 = y1;
    this.x2 = x2;
    this.y2 = y2;
    this.speed = speed;
    this.radius = 20;

    this.progress = 0;
    this.dir = 1; // 1 = forward, -1 = reverse
    this.angle = 0;

    this.totalDist = Math.hypot(x2 - x1, y2 - y1);
    this.duration = this.totalDist / this.speed;

    this.x = x1;
    this.y = y1;
  }

  update(dt, player, particles, audio) {
    this.angle += dt * 18; // Fast spin

    if (this.duration > 0) {
      this.progress += (dt / this.duration) * this.dir;
      if (this.progress >= 1) {
        this.progress = 1;
        this.dir = -1;
      } else if (this.progress <= 0) {
        this.progress = 0;
        this.dir = 1;
      }
    }

    this.x = this.x1 + (this.x2 - this.x1) * this.progress;
    this.y = this.y1 + (this.y2 - this.y1) * this.progress;

    if (particles && Math.random() < 0.2) {
      particles.createHitSparks(this.x, this.y, '#94a3b8');
    }
  }

  isActiveHazardAt(px, py, pradius = 16) {
    const dist = Math.hypot(px - this.x, py - this.y);
    return dist < (this.radius + pradius);
  }

  render(ctx) {
    ctx.save();

    // 1. Draw floor track slot
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 10;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(this.x1, this.y1);
    ctx.lineTo(this.x2, this.y2);
    ctx.stroke();

    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(this.x1, this.y1);
    ctx.lineTo(this.x2, this.y2);
    ctx.stroke();

    // 2. Draw spinning sawblade
    ctx.translate(this.x, this.y);
    ctx.rotate(this.angle);

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.arc(2, 4, this.radius, 0, Math.PI * 2);
    ctx.fill();

    // Blade Body
    ctx.fillStyle = '#64748b';
    ctx.beginPath();
    ctx.arc(0, 0, this.radius - 4, 0, Math.PI * 2);
    ctx.fill();

    // Serrated Teeth
    const teethCount = 8;
    ctx.fillStyle = '#cbd5e1';
    for (let i = 0; i < teethCount; i++) {
      const a = (i / teethCount) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * (this.radius - 4), Math.sin(a) * (this.radius - 4));
      ctx.lineTo(Math.cos(a + 0.2) * this.radius, Math.sin(a + 0.2) * this.radius);
      ctx.lineTo(Math.cos(a + 0.4) * (this.radius - 3), Math.sin(a + 0.4) * (this.radius - 3));
      ctx.closePath();
      ctx.fill();
    }

    // Steel Gleam line
    ctx.strokeStyle = '#f8fafc';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-this.radius + 6, 0);
    ctx.lineTo(this.radius - 6, 0);
    ctx.stroke();

    // Center brass bolt
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(0, 0, 5, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }
}
