// Persistent Game State Manager — stores meta-progression across runs
// Uses localStorage for persistence between sessions

const SAVE_KEY = 'gungeon_mythos_save';

const SKIN_CATALOG = [
  {
    id: 'default',
    name: 'Explorador',
    desc: 'O aventureiro clássico da Masmorra.',
    price: 0,
    bodyColor: '#2b6cb0',
    capeColor: '#1c3d5a',
    helmetColor: '#3182ce',
    emoji: '🔵'
  },
  {
    id: 'crimson',
    name: 'Guerreiro Carmesim',
    desc: 'Nascido no fogo da batalha.',
    price: 100,
    bodyColor: '#b91c1c',
    capeColor: '#7f1d1d',
    helmetColor: '#dc2626',
    emoji: '🔴'
  },
  {
    id: 'jade',
    name: 'Caçador Jade',
    desc: 'Veloz como a sombra das florestas.',
    price: 150,
    bodyColor: '#15803d',
    capeColor: '#14532d',
    helmetColor: '#16a34a',
    emoji: '🟢'
  },
  {
    id: 'obsidian',
    name: 'Fantasma Obsidiana',
    desc: 'Um ser das sombras entre os mundos.',
    price: 200,
    bodyColor: '#6d28d9',
    capeColor: '#3b0764',
    helmetColor: '#7c3aed',
    emoji: '🟣'
  },
  {
    id: 'golden',
    name: 'Lendário Dourado',
    desc: 'Apenas os mais bravos merecem este manto.',
    price: 400,
    bodyColor: '#d97706',
    capeColor: '#78350f',
    helmetColor: '#f59e0b',
    emoji: '🟡'
  }
];

const SHOP_ATTRIBUTES = [
  {
    id: 'attr_heart',
    name: '+1 Coração',
    desc: 'Aumenta o HP máximo em 2.',
    price: 80,
    emoji: '❤️',
    stackable: true,
    maxStack: 4
  },
  {
    id: 'attr_blank',
    name: 'Blank Extra',
    desc: 'Começa cada run com +1 Blank.',
    price: 60,
    emoji: '🛡️',
    stackable: true,
    maxStack: 3
  },
  {
    id: 'attr_speed',
    name: 'Botas Velozes',
    desc: 'Velocidade de movimento +30px/s.',
    price: 120,
    emoji: '👟',
    stackable: false
  },
  {
    id: 'attr_shotgun',
    name: 'Espingarda Inicial',
    desc: 'Começa com Espingarda no inventário.',
    price: 150,
    emoji: '💥',
    stackable: false
  },
  {
    id: 'attr_ak47',
    name: 'AK-47 Inicial',
    desc: 'Começa com o Fuzil AK-Myth no inventário.',
    price: 180,
    emoji: '⚡',
    stackable: false
  },
  {
    id: 'attr_sniper',
    name: 'Sniper Inicial',
    desc: 'Começa com o Rifle Sniper M99 no inventário.',
    price: 250,
    emoji: '🎯',
    stackable: false
  }
];

const DEFAULT_STATE = {
  runes: 0,              // Meta-currency (dropped by bosses)
  selectedSkin: 'default',
  unlockedSkins: ['default'],
  purchasedAttributes: {}, // { attrId: count }
  volume: 0.35,
  isMuted: false,
  showFPS: false,
  particlesEnabled: true,
  darkMode: true
};

class GameStateManager {
  constructor() {
    this.data = { ...DEFAULT_STATE };
    this.load();
  }

  load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        // Merge with defaults to handle new fields added in updates
        this.data = { ...DEFAULT_STATE, ...parsed };
        // Always ensure 'default' skin is unlocked
        if (!this.data.unlockedSkins.includes('default')) {
          this.data.unlockedSkins.push('default');
        }
      }
    } catch (e) {
      console.warn('Failed to load save data, using defaults.', e);
      this.data = { ...DEFAULT_STATE };
    }
  }

  save() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.data));
    } catch (e) {
      console.warn('Failed to save game state.', e);
    }
  }

  // --- RUNES ---
  get runes() { return this.data.runes; }

  addRunes(amount) {
    this.data.runes = Math.max(0, this.data.runes + amount);
    this.save();
  }

  // --- SKIN ---
  get selectedSkin() { return this.data.selectedSkin; }
  get unlockedSkins() { return this.data.unlockedSkins; }

  selectSkin(id) {
    if (this.data.unlockedSkins.includes(id)) {
      this.data.selectedSkin = id;
      this.save();
      return true;
    }
    return false;
  }

  buySkin(id) {
    const skin = SKIN_CATALOG.find(s => s.id === id);
    if (!skin) return false;
    if (this.data.unlockedSkins.includes(id)) return false;
    if (this.data.runes < skin.price) return false;
    this.data.runes -= skin.price;
    this.data.unlockedSkins.push(id);
    this.save();
    return true;
  }

  getSkinData(id) {
    return SKIN_CATALOG.find(s => s.id === id) || SKIN_CATALOG[0];
  }

  getActiveSkinData() {
    return this.getSkinData(this.data.selectedSkin);
  }

  // --- ATTRIBUTES ---
  get purchasedAttributes() { return this.data.purchasedAttributes; }

  getAttributeCount(id) {
    return this.data.purchasedAttributes[id] || 0;
  }

  buyAttribute(id) {
    const attr = SHOP_ATTRIBUTES.find(a => a.id === id);
    if (!attr) return false;
    const currentCount = this.getAttributeCount(id);
    if (attr.stackable && currentCount >= attr.maxStack) return false;
    if (!attr.stackable && currentCount >= 1) return false;
    if (this.data.runes < attr.price) return false;
    this.data.runes -= attr.price;
    this.data.purchasedAttributes[id] = currentCount + 1;
    this.save();
    return true;
  }

  // Compute active player bonus stats from purchased attributes
  getPlayerBonuses() {
    return {
      extraHealth: (this.getAttributeCount('attr_heart')) * 2,
      extraBlanks: this.getAttributeCount('attr_blank'),
      extraSpeed: this.getAttributeCount('attr_speed') > 0 ? 30 : 0,
      startShotgun: this.getAttributeCount('attr_shotgun') > 0,
      startAK47: this.getAttributeCount('attr_ak47') > 0,
      startSniper: this.getAttributeCount('attr_sniper') > 0
    };
  }

  // --- AUDIO ---
  get volume() { return this.data.volume; }
  get isMuted() { return this.data.isMuted; }

  setVolume(v) {
    this.data.volume = Math.max(0, Math.min(1, v));
    this.save();
  }

  toggleMute() {
    this.data.isMuted = !this.data.isMuted;
    this.save();
    return this.data.isMuted;
  }

  // --- SETTINGS ---
  get showFPS() { return this.data.showFPS; }
  get particlesEnabled() { return this.data.particlesEnabled; }
  get darkMode() { return this.data.darkMode; }

  toggleFPS() { this.data.showFPS = !this.data.showFPS; this.save(); }
  toggleParticles() { this.data.particlesEnabled = !this.data.particlesEnabled; this.save(); }
  toggleDarkMode() { this.data.darkMode = !this.data.darkMode; this.save(); }
}

export const gameState = new GameStateManager();
export { SKIN_CATALOG, SHOP_ATTRIBUTES };
