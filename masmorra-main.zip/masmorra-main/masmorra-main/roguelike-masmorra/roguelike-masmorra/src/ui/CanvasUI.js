// 100% Pure JavaScript Canvas UI Engine for HUD, Menus, Boss Bar, Minimap, and Crosshair
import { RoomType } from '../dungeon/Room.js';

export class CanvasUI {
  constructor() {
    this.buttons = []; // List of active clickable buttons for the current screen
    this.toast = null; // { text, timer, maxTimer }
    this.particles = []; // UI particles for title screen embers
    this.initTitleEmbers();
  }

  initTitleEmbers() {
    for (let i = 0; i < 40; i++) {
      this.particles.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 20,
        vy: -20 - Math.random() * 40,
        size: 2 + Math.random() * 3,
        alpha: 0.2 + Math.random() * 0.6,
        color: Math.random() < 0.5 ? '#ffaa00' : '#ff3344'
      });
    }
  }

  updateTitleEmbers(dt, width, height) {
    this.particles.forEach(p => {
      p.y += p.vy * dt;
      p.x += p.vx * dt;
      if (p.y < -10) {
        p.y = height + 10;
        p.x = Math.random() * width;
      }
    });
  }

  showToast(text, duration = 2.0) {
    this.toast = {
      text,
      timer: duration,
      maxTimer: duration
    };
  }

  updateToast(dt) {
    if (this.toast) {
      this.toast.timer -= dt;
      if (this.toast.timer <= 0) {
        this.toast = null;
      }
    }
  }

  // --- BUTTON MANAGEMENT ---
  clearButtons() {
    this.buttons = [];
  }

  registerButton(id, x, y, width, height, text, onClick, isGold = false) {
    this.buttons.push({
      id,
      x,
      y,
      width,
      height,
      text,
      onClick,
      isGold,
      isHovered: false
    });
  }

  handleMouseMove(mouseX, mouseY) {
    this.buttons.forEach(btn => {
      btn.isHovered = mouseX >= btn.x && mouseX <= btn.x + btn.width &&
                      mouseY >= btn.y && mouseY <= btn.y + btn.height;
    });
  }

  handleClick(mouseX, mouseY, audio) {
    for (const btn of this.buttons) {
      if (mouseX >= btn.x && mouseX <= btn.x + btn.width &&
          mouseY >= btn.y && mouseY <= btn.y + btn.height) {
        if (audio) audio.playHit();
        btn.onClick();
        return true;
      }
    }
    return false;
  }

  renderButton(ctx, btn) {
    ctx.save();
    const isHov = btn.isHovered;

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.fillRect(btn.x + 3, btn.y + 4, btn.width, btn.height);

    // Button body
    const baseColor = btn.isGold ? '#ffaa00' : '#ffcc00';
    const hovColor = btn.isGold ? '#ffc44d' : '#ffe066';
    ctx.fillStyle = isHov ? hovColor : baseColor;
    ctx.fillRect(btn.x, btn.y, btn.width, btn.height);

    // Bevel highlights & border
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.strokeRect(btn.x, btn.y, btn.width, btn.height);

    // Dark bottom edge (arcade depth)
    ctx.fillStyle = btn.isGold ? '#b37700' : '#b38f00';
    ctx.fillRect(btn.x, btn.y + btn.height - 4, btn.width, 4);

    // Button Text
    ctx.font = "bold 13px 'Press Start 2P', monospace";
    ctx.fillStyle = '#0a0a0f';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(btn.text, btn.x + btn.width / 2, btn.y + btn.height / 2 - 1);

    ctx.restore();
  }

  // --- CROSSHAIR ---
  drawCrosshair(ctx, mouseX, mouseY, isShooting) {
    ctx.save();
    ctx.translate(mouseX, mouseY);

    const size = isShooting ? 16 : 12;
    const gap = isShooting ? 8 : 5;

    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 2;
    ctx.shadowBlur = 8;
    ctx.shadowColor = '#ffcc00';

    // 4 prongs
    ctx.beginPath();
    // Top
    ctx.moveTo(0, -gap);
    ctx.lineTo(0, -size);
    // Bottom
    ctx.moveTo(0, gap);
    ctx.lineTo(0, size);
    // Left
    ctx.moveTo(-gap, 0);
    ctx.lineTo(-size, 0);
    // Right
    ctx.moveTo(gap, 0);
    ctx.lineTo(size, 0);
    ctx.stroke();

    // Center dot
    ctx.fillStyle = '#ff3344';
    ctx.beginPath();
    ctx.arc(0, 0, 2, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // --- IN-GAME HUD ---
  drawHUD(ctx, player, currentFloor, floorInfo, activeBoss, dungeon, currentRoom, interactionPrompt, bossDefeated) {
    if (!player) return;

    // 1. TOP-LEFT: HEARTS, BLANKS, KEYS, COINS
    ctx.save();
    const padX = 20;
    const padY = 20;

    // Background pill
    ctx.fillStyle = 'rgba(12, 14, 22, 0.85)';
    ctx.strokeStyle = 'rgba(255, 204, 0, 0.3)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(padX, padY, 230, 80, 8);
    ctx.fill();
    ctx.stroke();

    // Hearts (2 HP per heart container)
    const maxHearts = Math.ceil(player.maxHealth / 2);
    for (let i = 0; i < maxHearts; i++) {
      const hX = padX + 16 + i * 32;
      const hY = padY + 16;
      const heartHp = player.health - i * 2;

      this.drawHeart(ctx, hX, hY, heartHp);
    }

    // Sub-stats (Blanks, Keys, Coins)
    const statY = padY + 62;

    // Blanks
    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#00ddff';
    ctx.fillText('🛡️ Blanks:', padX + 14, statY);
    ctx.font = "bold 13px 'Press Start 2P', monospace";
    ctx.fillText(`x${player.blanks}`, padX + 80, statY - 1);
    ctx.font = "9px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.fillText('[Q]', padX + 110, statY - 1);

    // Coins
    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#ffaa00';
    ctx.fillText('🪙', padX + 155, statY);
    ctx.font = "bold 14px 'Press Start 2P', monospace";
    ctx.fillStyle = '#fff';
    ctx.fillText(`${player.coins}`, padX + 175, statY - 1);

    ctx.restore();

    // 2. TOP-RIGHT: FLOOR BADGE & MINIMAP
    ctx.save();
    const mmW = 140;
    const mmH = 140;
    const mmX = ctx.canvas.width - mmW - 20;
    const mmY = 56;

    // Floor title banner
    ctx.textAlign = 'right';
    ctx.font = "bold 12px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.fillText(`ANDAR ${currentFloor}`, ctx.canvas.width - 20, 28);
    ctx.font = "bold 14px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#9ca3af';
    ctx.fillText(floorInfo ? floorInfo.name : '', ctx.canvas.width - 20, 46);

    // Minimap Container
    ctx.fillStyle = 'rgba(9, 10, 18, 0.9)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(mmX, mmY, mmW, mmH, 6);
    ctx.fill();
    ctx.stroke();

    // Draw Minimap Content
    this.drawMinimap(ctx, mmX, mmY, mmW, mmH, dungeon, currentRoom, player);
    ctx.restore();

    // 3. BOTTOM-RIGHT: ENTER THE GUNGEON ARSENAL BAR & ACTIVE WEAPON
    ctx.save();
    const weapon = player.activeWeapon;
    const totalWeapons = player.weapons.length;

    // A) Arsenal Slots Bar (Thumbnails for all carried guns)
    const slotW = 54;
    const slotH = 50;
    const slotGap = 6;
    const arsenalTotalW = Math.max(260, totalWeapons * (slotW + slotGap) - slotGap);
    const arsenalX = ctx.canvas.width - arsenalTotalW - 20;
    const arsenalY = ctx.canvas.height - 180;

    // Background for arsenal bar
    ctx.fillStyle = 'rgba(8, 10, 16, 0.88)';
    ctx.strokeStyle = 'rgba(255, 204, 0, 0.25)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(arsenalX - 8, arsenalY - 6, arsenalTotalW + 16, slotH + 12, 8);
    ctx.fill();
    ctx.stroke();

    // Render each weapon slot in arsenal
    for (let i = 0; i < totalWeapons; i++) {
      const w = player.weapons[i];
      const sX = arsenalX + i * (slotW + slotGap);
      const sY = arsenalY;
      const isActive = (i === player.activeWeaponIndex);
      const isDepleted = (w.def.maxAmmo !== Infinity && w.currentClip === 0 && w.reserveAmmo === 0);

      // Slot container
      ctx.fillStyle = isActive ? 'rgba(30, 41, 59, 0.95)' : 'rgba(15, 23, 42, 0.7)';
      ctx.fillRect(sX, sY, slotW, slotH);

      if (isActive) {
        ctx.strokeStyle = '#fbbf24';
        ctx.lineWidth = 2.5;
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#fbbf24';
        ctx.strokeRect(sX, sY, slotW, slotH);
        ctx.shadowBlur = 0;
      } else if (isDepleted) {
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(sX, sY, slotW, slotH);
      } else {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.lineWidth = 1;
        ctx.strokeRect(sX, sY, slotW, slotH);
      }

      // Slot number badge [1], [2], etc.
      ctx.fillStyle = isActive ? '#fbbf24' : '#94a3b8';
      ctx.font = "bold 9px 'Press Start 2P', monospace";
      ctx.textAlign = 'left';
      ctx.fillText(`${i + 1}`, sX + 4, sY + 12);

      // Weapon Emoji Icon
      ctx.font = "18px sans-serif";
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(w.emoji, sX + slotW / 2, sY + 24);

      // Mini Ammo Bar or Empty text at bottom of slot
      if (w.def.maxAmmo === Infinity) {
        ctx.fillStyle = '#38bdf8';
        ctx.font = "bold 9px 'Press Start 2P', monospace";
        ctx.fillText('∞', sX + slotW / 2, sY + 42);
      } else if (isDepleted) {
        ctx.fillStyle = '#ef4444';
        ctx.font = "bold 7px 'Press Start 2P', monospace";
        ctx.fillText('0', sX + slotW / 2, sY + 42);
      } else {
        const ammoRatio = Math.min(1.0, (w.reserveAmmo + w.currentClip) / (w.def.maxAmmo + w.def.clipSize));
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(sX + 4, sY + 39, slotW - 8, 4);
        ctx.fillStyle = ammoRatio > 0.3 ? '#22c55e' : '#f59e0b';
        ctx.fillRect(sX + 4, sY + 39, (slotW - 8) * ammoRatio, 4);
      }
    }

    // B) Main Active Weapon Detail Card
    const wCardW = Math.max(arsenalTotalW + 16, 280);
    const wCardH = 96;
    const wCardX = ctx.canvas.width - wCardW - 20;
    const wCardY = ctx.canvas.height - wCardH - 14;

    ctx.fillStyle = 'rgba(10, 12, 20, 0.94)';
    ctx.strokeStyle = weapon.def.maxAmmo !== Infinity && weapon.currentClip === 0 && weapon.reserveAmmo === 0
      ? 'rgba(239, 68, 68, 0.8)'
      : 'rgba(255, 204, 0, 0.4)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(wCardX, wCardY, wCardW, wCardH, 8);
    ctx.fill();
    ctx.stroke();

    // Weapon Icon Box
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 1.5;
    ctx.fillRect(wCardX + 12, wCardY + 12, 54, 54);
    ctx.strokeRect(wCardX + 12, wCardY + 12, 54, 54);

    ctx.font = "28px sans-serif";
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(weapon.emoji, wCardX + 39, wCardY + 39);

    // Weapon Name
    ctx.textAlign = 'left';
    ctx.font = "bold 16px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#ffcc00';
    ctx.fillText(weapon.name, wCardX + 76, wCardY + 24);

    // Ammo Counter & Status
    const isOutOfAmmo = (weapon.def.maxAmmo !== Infinity && weapon.currentClip === 0 && weapon.reserveAmmo === 0);

    if (isOutOfAmmo) {
      ctx.font = "bold 11px 'Press Start 2P', monospace";
      ctx.fillStyle = '#ef4444';
      ctx.shadowBlur = 6;
      ctx.shadowColor = '#ef4444';
      ctx.fillText('SEM MUNIÇÃO!', wCardX + 76, wCardY + 46);
      ctx.shadowBlur = 0;
    } else {
      ctx.font = "bold 14px 'Press Start 2P', monospace";
      ctx.fillStyle = '#ffffff';
      const reserveText = weapon.def.maxAmmo === Infinity ? '∞' : String(weapon.reserveAmmo);
      ctx.fillText(`${weapon.currentClip} / ${reserveText}`, wCardX + 76, wCardY + 46);
    }

    // Reloading Indicator Bar
    if (weapon.isReloading) {
      const pct = weapon.getReloadProgress();
      ctx.fillStyle = '#ff3344';
      ctx.font = "bold 8px 'Press Start 2P', monospace";
      ctx.fillText('RECARREGANDO...', wCardX + 76, wCardY + 60);

      ctx.fillStyle = '#222';
      ctx.fillRect(wCardX + 76, wCardY + 64, 150, 4);
      ctx.fillStyle = '#ffcc00';
      ctx.fillRect(wCardX + 76, wCardY + 64, 150 * pct, 4);
    }

    // Controls hints footer: Drop [G], Quick Switch [TAB], Roll Cooldown
    const hintY = wCardY + 76;
    ctx.font = "bold 11px 'Rajdhani', sans-serif";

    // Show drop hint if droppable
    const canDrop = (!weapon.def.isStarter && weapon.id !== 'pistol' && weapon.def.maxAmmo !== Infinity && player.weapons.length > 1);
    ctx.fillStyle = canDrop ? '#f59e0b' : '#64748b';
    ctx.fillText(canDrop ? '[G] Dropar' : '[G] Fixo', wCardX + 76, hintY);

    ctx.fillStyle = '#38bdf8';
    ctx.fillText('[TAB] Trocar', wCardX + 138, hintY);

    // Dodge Roll Cooldown Bar (Bottom right of card)
    const rollPct = player.cooldownTimer > 0 ? (1 - player.cooldownTimer / player.rollCooldown) : 1;
    ctx.fillStyle = '#94a3b8';
    ctx.fillText('ESQUIVA:', wCardX + wCardW - 120, hintY);
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(wCardX + wCardW - 68, hintY - 9, 56, 8);
    ctx.fillStyle = rollPct >= 1 ? '#00ddff' : '#0284c7';
    ctx.fillRect(wCardX + wCardW - 68, hintY - 9, 56 * rollPct, 8);

    ctx.restore();

    // 4. TOP-CENTER: BOSS HEALTH BAR (When active)
    if (activeBoss && !activeBoss.isDead) {
      this.drawBossBar(ctx, activeBoss);
    } else if (bossDefeated) {
      // If Boss was defeated, draw prominent exit banner at top
      ctx.save();
      const bX = ctx.canvas.width / 2;
      const bY = 32;
      ctx.fillStyle = 'rgba(10, 24, 20, 0.9)';
      ctx.strokeStyle = '#00ffaa';
      ctx.lineWidth = 2;
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#00ffaa';
      ctx.beginPath();
      ctx.roundRect(bX - 220, bY - 16, 440, 36, 18);
      ctx.fill();
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.font = "bold 13px 'Rajdhani', sans-serif";
      ctx.fillStyle = '#00ffaa';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('▲ CÂMARA DO ELEVADOR ABERTA! SIGA PARA A SALA DE SAÍDA ▲', bX, bY + 2);
      ctx.restore();
    }

    // 5. CENTER TOAST MESSAGE (Floor cleared, etc.)
    if (this.toast) {
      ctx.save();
      const tX = ctx.canvas.width / 2;
      const tY = 120;
      ctx.font = "bold 14px 'Press Start 2P', monospace";
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffcc00';
      ctx.shadowBlur = 12;
      ctx.shadowColor = '#ffaa00';
      ctx.fillText(this.toast.text, tX, tY);
      ctx.restore();
    }

    // 6. INTERACTION PROMPT
    if (interactionPrompt) {
      ctx.save();
      const pX = ctx.canvas.width / 2;
      const pY = ctx.canvas.height - 90;

      ctx.fillStyle = 'rgba(10, 12, 20, 0.92)';
      ctx.strokeStyle = '#ffd700';
      ctx.lineWidth = 2.5;
      ctx.shadowBlur = 18;
      ctx.shadowColor = '#ffcc00';
      ctx.beginPath();
      ctx.roundRect(pX - 220, pY - 22, 440, 44, 22);
      ctx.fill();
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.font = "bold 15px 'Rajdhani', sans-serif";
      ctx.fillStyle = '#ffea75';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(interactionPrompt, pX, pY);
      ctx.restore();
    }
  }

  drawHeart(ctx, x, y, hp) {
    ctx.save();
    ctx.translate(x, y);

    if (hp >= 2) {
      // Full Heart
      ctx.fillStyle = '#ff2244';
      ctx.shadowBlur = 6;
      ctx.shadowColor = '#ff2244';
      this.drawHeartPath(ctx);
      ctx.fill();
    } else if (hp === 1) {
      // Half Heart
      ctx.fillStyle = 'rgba(255, 34, 68, 0.2)';
      this.drawHeartPath(ctx);
      ctx.fill();

      // Left half solid
      ctx.save();
      ctx.beginPath();
      ctx.rect(-14, -14, 14, 28);
      ctx.clip();
      ctx.fillStyle = '#ff2244';
      this.drawHeartPath(ctx);
      ctx.fill();
      ctx.restore();
    } else {
      // Empty Heart outline
      ctx.fillStyle = 'rgba(40, 40, 50, 0.6)';
      this.drawHeartPath(ctx);
      ctx.fill();
      ctx.strokeStyle = '#555';
      ctx.lineWidth = 1.5;
      this.drawHeartPath(ctx);
      ctx.stroke();
    }

    ctx.restore();
  }

  drawHeartPath(ctx) {
    ctx.beginPath();
    ctx.moveTo(0, 5);
    ctx.bezierCurveTo(-12, -8, -14, -14, -6, -18);
    ctx.bezierCurveTo(0, -18, 0, -12, 0, -10);
    ctx.bezierCurveTo(0, -12, 0, -18, 6, -18);
    ctx.bezierCurveTo(14, -14, 12, -8, 0, 5);
    ctx.closePath();
  }

  drawBossBar(ctx, boss) {
    ctx.save();
    const barW = Math.min(540, ctx.canvas.width * 0.75);
    const barH = 18;
    const barX = (ctx.canvas.width - barW) / 2;
    const barY = 28;

    // Boss Name & Title
    ctx.textAlign = 'center';
    ctx.font = "bold 13px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ff3344';
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#ff0033';
    ctx.fillText(boss.name.toUpperCase(), ctx.canvas.width / 2, barY - 8);

    ctx.font = "bold 12px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#d1d5db';
    ctx.shadowBlur = 0;
    ctx.fillText(boss.subtitle.toUpperCase(), ctx.canvas.width / 2, barY + 7);

    // Track frame
    ctx.fillStyle = '#1c0d12';
    ctx.fillRect(barX, barY + 15, barW, barH);
    ctx.strokeStyle = '#ff3344';
    ctx.lineWidth = 2;
    ctx.strokeRect(barX, barY + 15, barW, barH);

    // Fill
    const hpPct = Math.max(0, boss.health / boss.maxHealth);
    ctx.fillStyle = '#ff1a35';
    ctx.fillRect(barX + 2, barY + 17, (barW - 4) * hpPct, barH - 4);

    ctx.restore();
  }

  drawMinimap(ctx, mmX, mmY, mmW, mmH, dungeon, currentRoom, player) {
    if (!dungeon || !dungeon.rooms) return;

    let minGX = Infinity, maxGX = -Infinity;
    let minGY = Infinity, maxGY = -Infinity;
    dungeon.rooms.forEach(r => {
      minGX = Math.min(minGX, r.gridX);
      maxGX = Math.max(maxGX, r.gridX);
      minGY = Math.min(minGY, r.gridY);
      maxGY = Math.max(maxGY, r.gridY);
    });

    const spanX = Math.max(1, maxGX - minGX + 1);
    const spanY = Math.max(1, maxGY - minGY + 1);
    const rSize = Math.min(18, Math.floor(Math.min(mmW / (spanX + 1), mmH / (spanY + 1)) * 0.75));
    const spacing = rSize + 6;

    const cX = mmX + mmW / 2 - ((minGX + maxGX) / 2) * spacing;
    const cY = mmY + mmH / 2 - ((minGY + maxGY) / 2) * spacing;

    // Draw corridors
    dungeon.rooms.forEach(r => {
      if (!r.visited) return;
      const rx = cX + r.gridX * spacing;
      const ry = cY + r.gridY * spacing;

      if (r.neighbors['E'] && (r.neighbors['E'].visited || r.visited)) {
        ctx.strokeStyle = '#374151';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(rx, ry);
        ctx.lineTo(cX + r.neighbors['E'].gridX * spacing, ry);
        ctx.stroke();
      }
      if (r.neighbors['S'] && (r.neighbors['S'].visited || r.visited)) {
        ctx.strokeStyle = '#374151';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(rx, ry);
        ctx.lineTo(rx, cY + r.neighbors['S'].gridY * spacing);
        ctx.stroke();
      }
    });

    // Draw rooms
    dungeon.rooms.forEach(r => {
      const rx = cX + r.gridX * spacing;
      const ry = cY + r.gridY * spacing;
      const isCurrent = (r === currentRoom);
      const isAdjacent = Object.values(r.neighbors).some(n => n.visited);

      if (r.visited) {
        ctx.fillStyle = isCurrent ? '#1e3a8a' : '#111827';
        ctx.fillRect(rx - rSize / 2, ry - rSize / 2, rSize, rSize);
        ctx.strokeStyle = isCurrent ? '#00ddff' : (r.cleared ? '#4b5563' : '#ff3344');
        ctx.lineWidth = isCurrent ? 2 : 1;
        ctx.strokeRect(rx - rSize / 2, ry - rSize / 2, rSize, rSize);

        if (r.type === RoomType.BOSS) {
          ctx.font = '8px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('☠️', rx, ry);
        } else if (r.type === RoomType.CHEST) {
          ctx.font = '8px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('📦', rx, ry);
        } else if (r.type === RoomType.ELEVATOR) {
          ctx.font = '9px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🚪', rx, ry);
        }
      } else if (isAdjacent) {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.strokeRect(rx - rSize / 2, ry - rSize / 2, rSize, rSize);
      }

      if (isCurrent && player) {
        const relX = (player.x - r.x) / r.width;
        const relY = (player.y - r.y) / r.height;
        const px = (rx - rSize / 2) + relX * rSize;
        const py = (ry - rSize / 2) + relY * rSize;
        ctx.fillStyle = '#00ddff';
        ctx.beginPath();
        ctx.arc(px, py, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
    });
  }

  // --- OVERLAY: MAIN TITLE MENU ---
  drawMainMenu(ctx, width, height, dt, callbacks) {
    this.clearButtons();
    this.updateTitleEmbers(dt, width, height);

    // Dark gradient background
    const bg = ctx.createRadialGradient(width / 2, height / 2, 50, width / 2, height / 2, width * 0.8);
    bg.addColorStop(0, '#151624');
    bg.addColorStop(1, '#06070a');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    // Embers
    this.particles.forEach(p => {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.alpha;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1.0;

    // Card Container
    const cardW = Math.min(680, width * 0.92);
    const cardH = Math.min(560, height * 0.88);
    const cardX = (width - cardW) / 2;
    const cardY = (height - cardH) / 2;

    ctx.fillStyle = 'rgba(14, 16, 26, 0.97)';
    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 2;
    ctx.shadowBlur = 20;
    ctx.shadowColor = 'rgba(255, 204, 0, 0.3)';
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, cardH, 10);
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Title
    ctx.textAlign = 'center';
    const titleSize = Math.max(18, Math.min(28, Math.round(width * 0.035)));
    ctx.font = `bold ${titleSize}px 'Press Start 2P', monospace`;
    ctx.fillStyle = '#ffcc00';
    ctx.shadowBlur = 18;
    ctx.shadowColor = '#ff3344';
    ctx.fillText('GUNGEON MYTHOS', width / 2, cardY + 60);
    ctx.shadowBlur = 0;

    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#9ca3af';
    ctx.fillText('MASMORRA DOS DEUSES', width / 2, cardY + 88);

    // Divider
    ctx.strokeStyle = 'rgba(255, 204, 0, 0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cardX + 40, cardY + 104);
    ctx.lineTo(cardX + cardW - 40, cardY + 104);
    ctx.stroke();

    // 2x2 button grid
    const btnW = (cardW - 80) / 2 - 10;
    const btnH = 62;
    const col1 = cardX + 40;
    const col2 = cardX + 40 + btnW + 20;
    const row1 = cardY + 130;
    const row2 = cardY + 130 + btnH + 18;

    // JOGAR button (highlighted/gold)
    this.registerButton('play', col1, row1, btnW, btnH, '▶  JOGAR', callbacks.onPlay, true);

    // INVENTÁRIO
    this.registerButton('inventory', col2, row1, btnW, btnH, '🎒 INVENTÁRIO', callbacks.onInventory, false);

    // LOJA
    this.registerButton('shop', col1, row2, btnW, btnH, '🏪 LOJA', callbacks.onShop, false);

    // OPÇÕES
    this.registerButton('options', col2, row2, btnW, btnH, '⚙️  OPÇÕES', callbacks.onOptions, false);

    this.buttons.forEach(b => this.renderButton(ctx, b));

    // Controls hint (compact)
    const hintY = row2 + btnH + 28;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.beginPath();
    ctx.roundRect(cardX + 24, hintY, cardW - 48, 120, 6);
    ctx.fill();

    ctx.font = "bold 11px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.textAlign = 'center';
    ctx.fillText('CONTROLES RÁPIDOS', width / 2, hintY + 22);

    ctx.font = "bold 13px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#d1d5db';
    ctx.textAlign = 'left';
    const col1h = cardX + 44;
    const col2h = cardX + cardW / 2 + 10;
    ctx.fillText('[W A S D] — Mover', col1h, hintY + 50);
    ctx.fillText('[MOUSE ESQ] — Atirar', col1h, hintY + 72);
    ctx.fillText('[R] — Recarregar', col1h, hintY + 94);
    ctx.fillText('[ESPAÇO / DIR] — Rolamento', col2h, hintY + 50);
    ctx.fillText('[Q] — Blank (Aniquila Balas)', col2h, hintY + 72);
    ctx.fillText('[E] — Interagir', col2h, hintY + 94);

    // Rune balance badge (top right of card)
    if (callbacks.runes !== undefined) {
      ctx.save();
      ctx.fillStyle = 'rgba(80, 30, 120, 0.85)';
      ctx.strokeStyle = '#a855f7';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(cardX + cardW - 155, cardY + 10, 145, 32, 16);
      ctx.fill();
      ctx.stroke();
      ctx.font = "bold 13px 'Rajdhani', sans-serif";
      ctx.fillStyle = '#e9d5ff';
      ctx.textAlign = 'right';
      ctx.fillText(`🔮 ${callbacks.runes} Runas Míticas`, cardX + cardW - 16, cardY + 30);
      ctx.restore();
    }
  }

  // --- OVERLAY: FLOOR TRANSITION SCREEN ---
  drawFloorTransition(ctx, width, height, floorNumber, floorInfo, onContinue) {
    this.clearButtons();

    ctx.fillStyle = 'rgba(6, 7, 12, 0.94)';
    ctx.fillRect(0, 0, width, height);

    const cardW = Math.min(600, width * 0.9);
    const cardH = 440;
    const cardX = (width - cardW) / 2;
    const cardY = (height - cardH) / 2;

    ctx.fillStyle = 'rgba(18, 20, 30, 0.95)';
    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, cardH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.font = "36px sans-serif";
    ctx.fillText('☠️', width / 2, cardY + 50);

    ctx.font = "bold 20px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.fillText(`ANDAR ${floorNumber}`, width / 2, cardY + 95);

    ctx.font = "bold 17px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#9ca3af';
    ctx.fillText(floorInfo ? floorInfo.name : '', width / 2, cardY + 125);

    // Enemy Intel Box
    ctx.fillStyle = 'rgba(255, 51, 68, 0.1)';
    ctx.strokeStyle = 'rgba(255, 51, 68, 0.35)';
    ctx.fillRect(cardX + 24, cardY + 150, cardW - 48, 140);
    ctx.strokeRect(cardX + 24, cardY + 150, cardW - 48, 140);

    ctx.font = "bold 10px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ff3344';
    ctx.textAlign = 'left';
    ctx.fillText('AMEAÇAS DETECTADAS NESTE ANDAR:', cardX + 38, cardY + 175);

    ctx.font = "bold 14px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#f3f4f6';
    if (floorInfo && floorInfo.enemiesDesc) {
      floorInfo.enemiesDesc.forEach((desc, idx) => {
        ctx.fillText(`⚠️ ${desc}`, cardX + 38, cardY + 205 + idx * 24);
      });
    }

    // Boss tease
    ctx.textAlign = 'center';
    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#e5e7eb';
    ctx.fillText(`Guardião do Andar: ${floorInfo ? floorInfo.bossName + ' - ' + floorInfo.bossTitle : ''}`, width / 2, cardY + 325);

    // Button
    const btnW = 200;
    const btnH = 46;
    const btnX = (width - btnW) / 2;
    const btnY = cardY + 360;
    this.registerButton('continue', btnX, btnY, btnW, btnH, 'AVANÇAR', onContinue, true);

    this.buttons.forEach(b => this.renderButton(ctx, b));
  }

  // --- OVERLAY: GAME OVER ---
  drawGameOver(ctx, width, height, stats, onRestart) {
    this.clearButtons();

    ctx.fillStyle = 'rgba(8, 2, 4, 0.94)';
    ctx.fillRect(0, 0, width, height);

    const cardW = Math.min(540, width * 0.9);
    const cardH = 380;
    const cardX = (width - cardW) / 2;
    const cardY = (height - cardH) / 2;

    ctx.fillStyle = 'rgba(24, 10, 14, 0.96)';
    ctx.strokeStyle = '#ff3344';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, cardH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.font = "bold 20px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ff3344';
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#ff0033';
    ctx.fillText('VOCÊ TOMBOU NA MASMORRA', width / 2, cardY + 60);

    ctx.shadowBlur = 0;
    ctx.font = "bold 16px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#d1d5db';
    ctx.textAlign = 'left';
    ctx.fillText(`Andar Atingido: ${stats.floor}`, cardX + 60, cardY + 120);
    ctx.fillText(`Inimigos Eliminados: ${stats.kills}`, cardX + 60, cardY + 155);
    ctx.fillText(`Dano Infligido: ${stats.damage}`, cardX + 60, cardY + 190);
    ctx.fillText(`Arma Final: ${stats.weapon}`, cardX + 60, cardY + 225);

    const btnW = 240;
    const btnH = 46;
    const btnX = (width - btnW) / 2;
    const btnY = cardY + 285;
    this.registerButton('restart', btnX, btnY, btnW, btnH, 'TENTAR NOVAMENTE', onRestart, false);

    this.buttons.forEach(b => this.renderButton(ctx, b));
  }

  // --- OVERLAY: VICTORY ---
  drawVictory(ctx, width, height, stats, onRestart) {
    this.clearButtons();

    ctx.fillStyle = 'rgba(6, 8, 14, 0.94)';
    ctx.fillRect(0, 0, width, height);

    const cardW = Math.min(560, width * 0.9);
    const cardH = 420;
    const cardX = (width - cardW) / 2;
    const cardY = (height - cardH) / 2;

    ctx.fillStyle = 'rgba(18, 24, 38, 0.96)';
    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, cardH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.font = "36px sans-serif";
    ctx.fillText('👑 🐉 🗡️', width / 2, cardY + 50);

    ctx.font = "bold 22px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#ffaa00';
    ctx.fillText('VITÓRIA LENDÁRIA!', width / 2, cardY + 100);

    ctx.shadowBlur = 0;
    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#e5e7eb';
    ctx.fillText('Você derrotou Fáfnir, o Dragão Ancião, e conquistou a Masmorra dos Deuses!', width / 2, cardY + 135);

    ctx.textAlign = 'left';
    ctx.fillText(`Tempo de Incursão: ${stats.time}`, cardX + 60, cardY + 185);
    ctx.fillText(`Total de Vítimas: ${stats.kills}`, cardX + 60, cardY + 220);
    ctx.fillText(`Chefes Mitológicos Derrotados: 5 / 5`, cardX + 60, cardY + 255);

    const btnW = 240;
    const btnH = 46;
    const btnX = (width - btnW) / 2;
    const btnY = cardY + 325;
    this.registerButton('vic-restart', btnX, btnY, btnW, btnH, 'JOGAR OUTRA VEZ', onRestart, true);

    this.buttons.forEach(b => this.renderButton(ctx, b));
  }

  // ========================================================
  //  HELPER: Draw Mini Player Skin Preview
  // ========================================================
  drawSkinPreview(ctx, cx, cy, scale, skinData) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.beginPath();
    ctx.ellipse(0, 14, 16, 8, 0, 0, Math.PI * 2);
    ctx.fill();

    // Cape
    ctx.fillStyle = skinData.capeColor;
    ctx.beginPath();
    ctx.ellipse(-4, 4, 13, 15, 0, 0, Math.PI * 2);
    ctx.fill();

    // Body
    ctx.fillStyle = skinData.bodyColor;
    ctx.beginPath();
    ctx.arc(0, 0, 11, 0, Math.PI * 2);
    ctx.fill();

    // Bandolier
    ctx.strokeStyle = '#6d4c2b';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-8, -8);
    ctx.lineTo(8, 8);
    ctx.stroke();
    ctx.fillStyle = '#ffcc00';
    ctx.fillRect(-2, -2, 4, 4);

    // Helmet
    ctx.fillStyle = skinData.helmetColor;
    ctx.beginPath();
    ctx.arc(0, -9, 8, 0, Math.PI * 2);
    ctx.fill();

    // Eyes
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(2, -11, 3, 3);
    ctx.fillRect(6, -11, 3, 3);

    ctx.restore();
  }

  // ========================================================
  //  SCREEN: INVENTORY
  // ========================================================
  drawInventory(ctx, width, height, gameState, SKIN_CATALOG, callbacks) {
    this.clearButtons();

    // Background
    const bg = ctx.createRadialGradient(width / 2, height / 2, 40, width / 2, height / 2, width * 0.7);
    bg.addColorStop(0, '#0d1117');
    bg.addColorStop(1, '#060a0e');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    // Title
    ctx.textAlign = 'center';
    ctx.font = "bold 20px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.shadowBlur = 12;
    ctx.shadowColor = '#ffaa00';
    ctx.fillText('INVENTÁRIO', width / 2, 52);
    ctx.shadowBlur = 0;

    const panelY = 80;
    const panelH = height - 160;
    const halfW = (width - 80) / 2;

    // ---- LEFT PANEL: SKINS ----
    const leftX = 40;
    ctx.fillStyle = 'rgba(14, 18, 28, 0.95)';
    ctx.strokeStyle = 'rgba(255, 204, 0, 0.25)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(leftX, panelY, halfW, panelH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.font = "bold 12px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.textAlign = 'center';
    ctx.fillText('SKINS', leftX + halfW / 2, panelY + 28);

    const skinCols = 3;
    const skinCellW = (halfW - 40) / skinCols;
    const skinCellH = 120;
    const skinGridX = leftX + 20;
    const skinGridY = panelY + 50;

    SKIN_CATALOG.forEach((skin, idx) => {
      const col = idx % skinCols;
      const row = Math.floor(idx / skinCols);
      const cx = skinGridX + col * skinCellW + skinCellW / 2;
      const cy = skinGridY + row * skinCellH + 44;

      const isSelected = gameState.selectedSkin === skin.id;
      const isOwned = gameState.unlockedSkins.includes(skin.id);
      const cellX = skinGridX + col * skinCellW;
      const cellY = skinGridY + row * skinCellH;

      // Cell background
      ctx.fillStyle = isSelected
        ? 'rgba(255, 204, 0, 0.15)'
        : isOwned ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0,0,0,0.3)';
      ctx.strokeStyle = isSelected ? '#ffcc00' : isOwned ? '#374151' : '#1f2937';
      ctx.lineWidth = isSelected ? 2 : 1;
      ctx.beginPath();
      ctx.roundRect(cellX + 4, cellY + 4, skinCellW - 8, skinCellH - 8, 6);
      ctx.fill();
      ctx.stroke();

      if (isOwned) {
        this.drawSkinPreview(ctx, cx, cy, 1.5, skin);
      } else {
        // Locked overlay
        ctx.fillStyle = 'rgba(0,0,0,0.5)';
        ctx.beginPath();
        ctx.roundRect(cellX + 4, cellY + 4, skinCellW - 8, skinCellH - 8, 6);
        ctx.fill();
        ctx.font = '24px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('🔒', cx, cy + 8);
        ctx.font = "bold 11px 'Rajdhani', sans-serif";
        ctx.fillStyle = '#a855f7';
        ctx.fillText(`🔮 ${skin.price}`, cx, cy + 30);
      }

      // Skin name
      ctx.font = "bold 10px 'Rajdhani', sans-serif";
      ctx.fillStyle = isSelected ? '#ffcc00' : isOwned ? '#e5e7eb' : '#6b7280';
      ctx.textAlign = 'center';
      ctx.fillText(skin.name, cx, cellY + skinCellH - 10);

      if (isSelected) {
        ctx.font = "bold 9px 'Press Start 2P', monospace";
        ctx.fillStyle = '#22c55e';
        ctx.fillText('ATIVO', cx, cellY + skinCellH - 24);
      }

      // Register click area for owned skins
      if (isOwned) {
        this.registerButton(
          `skin_${skin.id}`,
          cellX + 4, cellY + 4, skinCellW - 8, skinCellH - 8,
          '',
          () => callbacks.onSelectSkin(skin.id),
          false
        );
      }
    });

    // ---- RIGHT PANEL: STARTING WEAPON ----
    const rightX = leftX + halfW + 40;
    ctx.fillStyle = 'rgba(14, 18, 28, 0.95)';
    ctx.strokeStyle = 'rgba(255, 204, 0, 0.25)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(rightX, panelY, halfW, panelH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.font = "bold 12px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.textAlign = 'center';
    ctx.fillText('ARMAS DESBLOQUEADAS', rightX + halfW / 2, panelY + 28);

    ctx.font = "bold 11px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#9ca3af';
    ctx.fillText('Compre na Loja para desbloquear.', rightX + halfW / 2, panelY + 48);

    const bonuses = gameState.getPlayerBonuses();
    const weaponList = [
      { id: 'pistol', name: 'Pistola de Serviço', emoji: '🔫', always: true },
      { id: 'shotgun', name: 'Espingarda Caçadeira', emoji: '💥', unlocked: bonuses.startShotgun },
      { id: 'ak47', name: 'Fuzil AK-Myth', emoji: '⚡', unlocked: bonuses.startAK47 },
      { id: 'sniper', name: 'Rifle Sniper M99', emoji: '🎯', unlocked: bonuses.startSniper }
    ];

    weaponList.forEach((w, i) => {
      const wy = panelY + 70 + i * 70;
      const wx = rightX + 16;
      const ww = halfW - 32;
      const isUnlocked = w.always || w.unlocked;

      ctx.fillStyle = isUnlocked ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.3)';
      ctx.strokeStyle = isUnlocked ? '#374151' : '#1f2937';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(wx, wy, ww, 54, 6);
      ctx.fill();
      ctx.stroke();

      ctx.font = '28px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(w.emoji, wx + 14, wy + 34);

      ctx.font = "bold 14px 'Rajdhani', sans-serif";
      ctx.fillStyle = isUnlocked ? '#e5e7eb' : '#4b5563';
      ctx.fillText(w.name, wx + 54, wy + 24);

      if (!isUnlocked) {
        ctx.font = "bold 11px 'Rajdhani', sans-serif";
        ctx.fillStyle = '#6b7280';
        ctx.fillText('🔒 Compre na Loja', wx + 54, wy + 40);
      } else {
        ctx.font = "bold 11px 'Rajdhani', sans-serif";
        ctx.fillStyle = '#22c55e';
        ctx.fillText('✓ Disponível ao iniciar', wx + 54, wy + 40);
      }
    });

    // Bonus stats panel
    const statY = panelY + 360;
    ctx.fillStyle = 'rgba(0,255,150,0.05)';
    ctx.strokeStyle = 'rgba(0,200,100,0.25)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(rightX + 16, statY, halfW - 32, 100, 6);
    ctx.fill();
    ctx.stroke();

    ctx.font = "bold 11px 'Press Start 2P', monospace";
    ctx.fillStyle = '#22c55e';
    ctx.textAlign = 'left';
    ctx.fillText('BÔNUS ATIVOS', rightX + 28, statY + 20);

    ctx.font = "bold 13px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#d1d5db';
    ctx.fillText(`❤️  HP Máximo: ${6 + bonuses.extraHealth}   (${bonuses.extraHealth > 0 ? '+' + bonuses.extraHealth : 'base'})`, rightX + 28, statY + 44);
    ctx.fillText(`🛡️  Blanks: ${2 + bonuses.extraBlanks}   👟 Veloc.: +${bonuses.extraSpeed}px/s`, rightX + 28, statY + 64);

    // Back Button
    const backBtnW = 200;
    const backBtnX = (width - backBtnW) / 2;
    const backBtnY = height - 68;
    this.registerButton('inv-back', backBtnX, backBtnY, backBtnW, 46, '← VOLTAR', callbacks.onBack, false);

    this.buttons.forEach(b => this.renderButton(ctx, b));
  }

  // ========================================================
  //  SCREEN: SHOP
  // ========================================================
  drawShop(ctx, width, height, gameState, SKIN_CATALOG, SHOP_ATTRIBUTES, callbacks) {
    this.clearButtons();

    const bg = ctx.createRadialGradient(width / 2, height / 2, 40, width / 2, height / 2, width * 0.7);
    bg.addColorStop(0, '#0a0d16');
    bg.addColorStop(1, '#05070b');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    // Header
    ctx.textAlign = 'center';
    ctx.font = "bold 20px 'Press Start 2P', monospace";
    ctx.fillStyle = '#a855f7';
    ctx.shadowBlur = 14;
    ctx.shadowColor = '#7c3aed';
    ctx.fillText('LOJA MÍSTICA', width / 2, 50);
    ctx.shadowBlur = 0;

    // Rune balance badge
    const badgeW = 220;
    const badgeX = (width - badgeW) / 2;
    ctx.fillStyle = 'rgba(80, 30, 120, 0.85)';
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(badgeX, 62, badgeW, 34, 17);
    ctx.fill();
    ctx.stroke();
    ctx.font = "bold 14px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#e9d5ff';
    ctx.textAlign = 'center';
    ctx.fillText(`🔮 ${gameState.runes} Runas Míticas`, width / 2, 83);

    // Two columns
    const colW = (width - 80) / 2;
    const colLeftX = 40;
    const colRightX = 40 + colW + 20;
    const colY = 108;
    const colH = height - 180;

    // ---- LEFT: SKINS ----
    ctx.fillStyle = 'rgba(14, 18, 28, 0.95)';
    ctx.strokeStyle = 'rgba(168, 85, 247, 0.3)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(colLeftX, colY, colW, colH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.font = "bold 11px 'Press Start 2P', monospace";
    ctx.fillStyle = '#c084fc';
    ctx.textAlign = 'center';
    ctx.fillText('✨ SKINS', colLeftX + colW / 2, colY + 24);

    const skinsToBuy = SKIN_CATALOG.filter(s => s.price > 0);
    skinsToBuy.forEach((skin, i) => {
      const itemY = colY + 40 + i * 82;
      const itemX = colLeftX + 12;
      const itemW = colW - 24;
      const owned = gameState.unlockedSkins.includes(skin.id);

      ctx.fillStyle = owned ? 'rgba(34, 197, 94, 0.06)' : 'rgba(255,255,255,0.04)';
      ctx.strokeStyle = owned ? '#166534' : '#374151';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(itemX, itemY, itemW, 70, 6);
      ctx.fill();
      ctx.stroke();

      // Skin preview (small)
      this.drawSkinPreview(ctx, itemX + 34, itemY + 36, 1.1, skin);

      ctx.textAlign = 'left';
      ctx.font = `bold 14px 'Rajdhani', sans-serif`;
      ctx.fillStyle = owned ? '#22c55e' : '#e5e7eb';
      ctx.fillText(skin.name, itemX + 68, itemY + 24);

      ctx.font = `13px 'Rajdhani', sans-serif`;
      ctx.fillStyle = '#9ca3af';
      ctx.fillText(skin.desc, itemX + 68, itemY + 42);

      if (owned) {
        ctx.font = "bold 12px 'Rajdhani', sans-serif";
        ctx.fillStyle = '#22c55e';
        ctx.fillText('✓ OBTIDA', itemX + 68, itemY + 58);
      } else {
        const canAfford = gameState.runes >= skin.price;
        const bw = 80;
        const bx = itemX + itemW - bw - 8;
        const by = itemY + 21;

        ctx.fillStyle = canAfford ? '#7c3aed' : '#1f2937';
        ctx.strokeStyle = canAfford ? '#a855f7' : '#374151';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(bx, by, bw, 28, 14);
        ctx.fill();
        ctx.stroke();

        ctx.font = "bold 11px 'Rajdhani', sans-serif";
        ctx.fillStyle = canAfford ? '#e9d5ff' : '#4b5563';
        ctx.textAlign = 'center';
        ctx.fillText(`🔮 ${skin.price}`, bx + bw / 2, by + 17);

        if (canAfford) {
          this.registerButton(
            `buy_skin_${skin.id}`,
            bx, by, bw, 28,
            '',
            () => callbacks.onBuySkin(skin.id),
            false
          );
        }
      }
    });

    // ---- RIGHT: ATTRIBUTES ----
    ctx.fillStyle = 'rgba(14, 18, 28, 0.95)';
    ctx.strokeStyle = 'rgba(255, 170, 0, 0.3)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(colRightX, colY, colW, colH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.font = "bold 11px 'Press Start 2P', monospace";
    ctx.fillStyle = '#fbbf24';
    ctx.textAlign = 'center';
    ctx.fillText('⚡ ATRIBUTOS & ARMAS', colRightX + colW / 2, colY + 24);

    SHOP_ATTRIBUTES.forEach((attr, i) => {
      const itemY = colY + 40 + i * 74;
      const itemX = colRightX + 12;
      const itemW = colW - 24;
      const count = gameState.getAttributeCount(attr.id);
      const maxReached = attr.stackable ? count >= attr.maxStack : count >= 1;

      ctx.fillStyle = maxReached ? 'rgba(34,197,94,0.06)' : 'rgba(255,255,255,0.04)';
      ctx.strokeStyle = maxReached ? '#166534' : '#374151';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(itemX, itemY, itemW, 62, 6);
      ctx.fill();
      ctx.stroke();

      ctx.font = '24px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(attr.emoji, itemX + 12, itemY + 38);

      ctx.font = "bold 14px 'Rajdhani', sans-serif";
      ctx.fillStyle = '#e5e7eb';
      ctx.fillText(attr.name, itemX + 50, itemY + 22);

      ctx.font = "12px 'Rajdhani', sans-serif";
      ctx.fillStyle = '#9ca3af';
      ctx.fillText(attr.desc, itemX + 50, itemY + 38);

      if (attr.stackable) {
        ctx.font = "bold 11px 'Rajdhani', sans-serif";
        ctx.fillStyle = '#6b7280';
        ctx.fillText(`(${count}/${attr.maxStack})`, itemX + 50, itemY + 54);
      }

      if (maxReached) {
        ctx.font = "bold 12px 'Rajdhani', sans-serif";
        ctx.fillStyle = '#22c55e';
        ctx.textAlign = 'right';
        ctx.fillText('✓ MÁXIMO', itemX + itemW - 10, itemY + 38);
      } else {
        const canAfford = gameState.runes >= attr.price;
        const bw = 85;
        const bx = itemX + itemW - bw - 8;
        const by = itemY + 16;

        ctx.fillStyle = canAfford ? '#92400e' : '#1f2937';
        ctx.strokeStyle = canAfford ? '#fbbf24' : '#374151';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(bx, by, bw, 28, 14);
        ctx.fill();
        ctx.stroke();

        ctx.font = "bold 11px 'Rajdhani', sans-serif";
        ctx.fillStyle = canAfford ? '#fef3c7' : '#4b5563';
        ctx.textAlign = 'center';
        ctx.fillText(`🔮 ${attr.price}`, bx + bw / 2, by + 17);

        if (canAfford) {
          this.registerButton(
            `buy_attr_${attr.id}`,
            bx, by, bw, 28,
            '',
            () => callbacks.onBuyAttr(attr.id),
            false
          );
        }
      }
    });

    // Back button
    const backBtnW = 200;
    const backBtnX = (width - backBtnW) / 2;
    const backBtnY = height - 68;
    this.registerButton('shop-back', backBtnX, backBtnY, backBtnW, 46, '← VOLTAR', callbacks.onBack, false);

    this.buttons.forEach(b => this.renderButton(ctx, b));
  }

  // ========================================================
  //  SCREEN: OPTIONS
  // ========================================================
  drawOptions(ctx, width, height, gameState, audio, callbacks) {
    this.clearButtons();

    const bg = ctx.createRadialGradient(width / 2, height / 2, 40, width / 2, height / 2, width * 0.7);
    bg.addColorStop(0, '#0d1018');
    bg.addColorStop(1, '#060709');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    ctx.textAlign = 'center';
    ctx.font = "bold 18px 'Press Start 2P', monospace";
    ctx.fillStyle = '#00ddff';
    ctx.shadowBlur = 12;
    ctx.shadowColor = '#0099bb';
    ctx.fillText('OPÇÕES', width / 2, 50);
    ctx.shadowBlur = 0;

    const cardW = Math.min(600, width * 0.9);
    const cardX = (width - cardW) / 2;
    const rowH = 64;
    let rowY = 84;

    const drawSection = (title, y) => {
      ctx.font = "bold 10px 'Press Start 2P', monospace";
      ctx.fillStyle = '#374151';
      ctx.textAlign = 'left';
      ctx.fillText(title, cardX, y);
      ctx.strokeStyle = 'rgba(255,255,255,0.08)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(cardX, y + 6);
      ctx.lineTo(cardX + cardW, y + 6);
      ctx.stroke();
    };

    const drawToggle = (id, label, value, x, y, w, onToggle) => {
      ctx.fillStyle = 'rgba(14,18,28,0.9)';
      ctx.strokeStyle = 'rgba(255,255,255,0.1)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(x, y, w, 50, 8);
      ctx.fill();
      ctx.stroke();

      ctx.font = "bold 14px 'Rajdhani', sans-serif";
      ctx.fillStyle = '#e5e7eb';
      ctx.textAlign = 'left';
      ctx.fillText(label, x + 16, y + 28);

      // Toggle pill
      const tw = 52;
      const th = 26;
      const tx = x + w - tw - 14;
      const ty = y + 12;
      ctx.fillStyle = value ? '#16a34a' : '#374151';
      ctx.beginPath();
      ctx.roundRect(tx, ty, tw, th, th / 2);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(value ? tx + tw - th / 2 : tx + th / 2, ty + th / 2, th / 2 - 3, 0, Math.PI * 2);
      ctx.fill();

      this.registerButton(id, tx - 4, ty - 4, tw + 8, th + 8, '', onToggle, false);
    };

    // --- AUDIO SECTION ---
    drawSection('ÁUDIO', rowY);
    rowY += 18;

    // Volume slider row
    const sliderRowY = rowY;
    ctx.fillStyle = 'rgba(14,18,28,0.9)';
    ctx.strokeStyle = 'rgba(255,255,255,0.1)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(cardX, sliderRowY, cardW, 50, 8);
    ctx.fill();
    ctx.stroke();

    ctx.font = "bold 14px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#e5e7eb';
    ctx.textAlign = 'left';
    ctx.fillText('🔊 Volume', cardX + 16, sliderRowY + 28);

    // Slider bar
    const sliderX = cardX + 130;
    const sliderW = cardW - 200;
    const sliderY = sliderRowY + 22;
    const vol = gameState.isMuted ? 0 : gameState.volume;

    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.roundRect(sliderX, sliderY, sliderW, 8, 4);
    ctx.fill();

    ctx.fillStyle = '#00ddff';
    ctx.beginPath();
    ctx.roundRect(sliderX, sliderY, sliderW * vol, 8, 4);
    ctx.fill();

    // Slider thumb
    ctx.fillStyle = '#ffffff';
    ctx.shadowBlur = 6;
    ctx.shadowColor = '#00ddff';
    ctx.beginPath();
    ctx.arc(sliderX + sliderW * vol, sliderY + 4, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Volume % label
    ctx.font = "bold 12px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#9ca3af';
    ctx.textAlign = 'right';
    ctx.fillText(`${Math.round(vol * 100)}%`, cardX + cardW - 8, sliderRowY + 28);

    // Register slider as a wide click zone
    this.registerButton('vol-slider', sliderX - 8, sliderRowY, sliderW + 16, 50, '', (e) => {
      if (e && e._rawX !== undefined) {
        const pct = Math.max(0, Math.min(1, (e._rawX - sliderX) / sliderW));
        callbacks.onVolumeChange(pct);
      }
    }, false);

    rowY += 58;

    // Mute toggle
    drawToggle('mute-toggle', '🔇 Mudo', gameState.isMuted, cardX, rowY, cardW, callbacks.onToggleMute);
    rowY += 58;

    // --- VISUAL SECTION ---
    drawSection('VISUAL', rowY);
    rowY += 18;

    const halfCardW = (cardW - 12) / 2;
    drawToggle('dark-toggle', '🌙 Modo Escuro', gameState.darkMode, cardX, rowY, halfCardW, callbacks.onToggleDark);
    drawToggle('particles-toggle', '✨ Partículas', gameState.particlesEnabled, cardX + halfCardW + 12, rowY, halfCardW, callbacks.onToggleParticles);
    rowY += 58;

    drawToggle('fps-toggle', '📊 Mostrar FPS', gameState.showFPS, cardX, rowY, halfCardW, callbacks.onToggleFPS);
    rowY += 58;

    // --- CONTROLS SECTION ---
    drawSection('CONTROLES', rowY);
    rowY += 18;

    ctx.fillStyle = 'rgba(14,18,28,0.9)';
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(cardX, rowY, cardW, 100, 8);
    ctx.fill();
    ctx.stroke();

    ctx.font = "bold 13px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#d1d5db';
    ctx.textAlign = 'left';
    ctx.fillText('[W A S D] — Mover          [ESPAÇO / DIR] — Rolamento', cardX + 16, rowY + 24);
    ctx.fillText('[MOUSE ESQ] — Atirar       [Q / MEIO] — Blank', cardX + 16, rowY + 46);
    ctx.fillText('[R] — Recarregar           [E] — Interagir', cardX + 16, rowY + 68);
    ctx.fillText('[1-9] — Trocar Arma        [ESC] — Pausar', cardX + 16, rowY + 90);
    rowY += 110;

    // Back
    const backBtnW = 200;
    const backBtnX = (width - backBtnW) / 2;
    this.registerButton('opt-back', backBtnX, rowY + 10, backBtnW, 46, '← VOLTAR', callbacks.onBack, false);

    this.buttons.forEach(b => this.renderButton(ctx, b));
  }
}
