// Base Entity class
export class Entity {
  constructor(x, y, radius = 16, health = 100) {
    this.x = x;
    this.y = y;
    this.vx = 0;
    this.vy = 0;
    this.radius = radius;
    this.maxHealth = health;
    this.health = health;
    this.isDead = false;
    this.friction = 8.0;

    // Visual flash on hit
    this.flashTimer = 0;
  }

  takeDamage(amount) {
    if (this.isDead) return 0;
    this.health -= amount;
    this.flashTimer = 0.12;

    if (this.health <= 0) {
      this.health = 0;
      this.isDead = true;
    }
    return amount;
  }

  updatePhysics(dt) {
    this.x += this.vx * dt;
    this.y += this.vy * dt;

    this.vx *= Math.max(0, 1 - this.friction * dt);
    this.vy *= Math.max(0, 1 - this.friction * dt);

    if (this.flashTimer > 0) {
      this.flashTimer -= dt;
    }
  }

  // Resolve collision against room boundaries, corridors, and pillars
  resolveEnvironmentCollisions(currentRoom, allRooms) {
    if (!currentRoom) return;

    // 1. Pillar collisions (smooth circular sliding)
    if (currentRoom.pillars) {
      currentRoom.pillars.forEach(pillar => {
        const dx = this.x - pillar.x;
        const dy = this.y - pillar.y;
        const dist = Math.hypot(dx, dy);
        const minDist = this.radius + pillar.radius;

        if (dist < minDist && dist > 0.0001) {
          const overlap = minDist - dist;
          const nx = dx / dist;
          const ny = dy / dist;
          this.x += nx * overlap;
          this.y += ny * overlap;

          // Smooth sliding: remove velocity heading directly into pillar
          const vDotN = this.vx * nx + this.vy * ny;
          if (vDotN < 0) {
            this.vx -= nx * vDotN;
            this.vy -= ny * vDotN;
          }
        }
      });
    }

    // 2. Room wall collisions
    const isLocked = currentRoom.doors.some(d => d.isLocked);

    if (isLocked) {
      // Clamp strictly inside room with velocity cancellation
      const minX = currentRoom.x + this.radius;
      const maxX = currentRoom.x + currentRoom.width - this.radius;
      const minY = currentRoom.y + this.radius;
      const maxY = currentRoom.y + currentRoom.height - this.radius;

      if (this.x < minX) { this.x = minX; if (this.vx < 0) this.vx = 0; }
      if (this.x > maxX) { this.x = maxX; if (this.vx > 0) this.vx = 0; }
      if (this.y < minY) { this.y = minY; if (this.vy < 0) this.vy = 0; }
      if (this.y > maxY) { this.y = maxY; if (this.vy > 0) this.vy = 0; }
    } else {
      // When unlocked, check if player is near a doorway corridor
      let inDoorCorridor = false;

      for (const door of currentRoom.doors) {
        if (door.dir === 'N' || door.dir === 'S') {
          if (this.x >= door.x && this.x <= door.x + door.width) {
            inDoorCorridor = true;
            break;
          }
        } else {
          if (this.y >= door.y && this.y <= door.y + door.height) {
            inDoorCorridor = true;
            break;
          }
        }
      }

      if (!inDoorCorridor) {
        const minX = currentRoom.x + this.radius;
        const maxX = currentRoom.x + currentRoom.width - this.radius;
        const minY = currentRoom.y + this.radius;
        const maxY = currentRoom.y + currentRoom.height - this.radius;

        if (this.x < minX || this.x > maxX || this.y < minY || this.y > maxY) {
          let inAnyRoom = allRooms.some(r => r.contains(this.x, this.y));
          if (!inAnyRoom) {
            let inCorridor = false;
            for (const r of allRooms) {
              if (r.neighbors['E']) {
                const nextR = r.neighbors['E'];
                const cX = r.x + r.width;
                const cY = r.y + (r.height - 100) / 2;
                const cW = nextR.x - cX;
                const cH = 100;
                if (this.x >= cX && this.x <= cX + cW && this.y >= cY && this.y <= cY + cH) {
                  inCorridor = true;
                  this.y = Math.max(cY + this.radius, Math.min(cY + cH - this.radius, this.y));
                  break;
                }
              }
              if (r.neighbors['S']) {
                const nextR = r.neighbors['S'];
                const cX = r.x + (r.width - 100) / 2;
                const cY = r.y + r.height;
                const cW = 100;
                const cH = nextR.y - cY;
                if (this.x >= cX && this.x <= cX + cW && this.y >= cY && this.y <= cY + cH) {
                  inCorridor = true;
                  this.x = Math.max(cX + this.radius, Math.min(cX + cW - this.radius, this.x));
                  break;
                }
              }
            }
            if (!inCorridor) {
              if (this.x < minX) { this.x = minX; if (this.vx < 0) this.vx = 0; }
              if (this.x > maxX) { this.x = maxX; if (this.vx > 0) this.vx = 0; }
              if (this.y < minY) { this.y = minY; if (this.vy < 0) this.vy = 0; }
              if (this.y > maxY) { this.y = maxY; if (this.vy > 0) this.vy = 0; }
            }
          }
        }
      }
    }
  }

  // Push apart from other entity smoothly to avoid stacking and vibration
  resolveSeparation(other, padding = 4) {
    if (!other || other === this || other.isDead) return;
    const dx = this.x - other.x;
    const dy = this.y - other.y;
    const dist = Math.hypot(dx, dy);
    const minDist = this.radius + other.radius + padding;

    if (dist < minDist && dist > 0.0001) {
      const overlap = (minDist - dist) * 0.5;
      const nx = dx / dist;
      const ny = dy / dist;
      this.x += nx * overlap;
      this.y += ny * overlap;
      other.x -= nx * overlap;
      other.y -= ny * overlap;

      // Soft velocity damping between colliding entities (smooth separation)
      const relVx = this.vx - other.vx;
      const relVy = this.vy - other.vy;
      const relDotN = relVx * nx + relVy * ny;
      if (relDotN < 0) {
        this.vx -= nx * (relDotN * 0.5);
        this.vy -= ny * (relDotN * 0.5);
        other.vx += nx * (relDotN * 0.5);
        other.vy += ny * (relDotN * 0.5);
      }
    }
  }
}
