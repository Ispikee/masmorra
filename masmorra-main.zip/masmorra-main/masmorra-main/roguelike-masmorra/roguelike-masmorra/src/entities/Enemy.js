import { Entity } from './Entity.js';
import { Bullet } from '../combat/Bullet.js';

export const EnemyType = {
  PISTOL: 'pistol',
  SMG: 'smg',
  SNIPER: 'sniper',
  BAZOOKA: 'bazooka',
  GATLING: 'gatling',
  MAGE: 'mage',
  BOMBER: 'bomber',
  SHIELD: 'shield',
  SLIME: 'slime'
};

export class Enemy extends Entity {
  constructor(x, y, type = EnemyType.PISTOL) {
    let radius = 16;
    let health = 45;

    if (type === EnemyType.SMG) { radius = 16; health = 60; }
    if (type === EnemyType.SNIPER) { radius = 15; health = 40; }
    if (type === EnemyType.BAZOOKA) { radius = 20; health = 95; }
    if (type === EnemyType.GATLING) { radius = 24; health = 160; }
    if (type === EnemyType.MAGE) { radius = 17; health = 70; }
    if (type === EnemyType.BOMBER) { radius = 14; health = 35; }
    if (type === EnemyType.SHIELD) { radius = 19; health = 125; }
    if (type === EnemyType.SLIME) { radius = 17; health = 80; }

    super(x, y, radius, health);
    this.type = type;

    this.shootTimer = 1.0 + Math.random() * 1.5;
    this.stateTimer = 0;
    this.aimAngle = 0;
    this.speed = 100;

    // Smooth movement & organic animation (Enter the Gungeon fluidity)
    this.targetVx = 0;
    this.targetVy = 0;
    this.walkTimer = Math.random() * Math.PI * 2;

    // Telegraphing & Windup (Enter the Gungeon mechanic: enemies telegraph attacks before shooting)
    this.isWindingUp = false;
    this.windupTimer = 0;
    this.windupDuration = 0.26;

    // Strafe direction (+1 or -1) for tactical movement
    this.strafeDir = Math.random() < 0.5 ? 1 : -1;
    this.strafeTimer = 1.0 + Math.random() * 2.0;

    // Telegraphing for Sniper laser
    this.isAimingLaser = false;
    this.laserLocked = false;
    this.lockedLaserAngle = 0;
    this.laserTimer = 0;

    // Burst firing for SMG
    this.burstRemaining = 0;
    this.burstTimer = 0;

    // Gatling spinup
    this.isSpinningUp = false;
    this.gatlingStreamTimer = 0;

    // Mage state
    this.teleportCooldown = 2.5;

    // Bomber state
    this.fuseTimer = 3.6;
    this.isTicking = false;

    // Shield state
    this.shieldOpenTimer = 0; // When > 0, shield is lowered to shoot

    // Slime state
    this.squishTimer = 0;
  }

  takeDamage(amount, sourceX = null, sourceY = null, knockback = 0) {
    // Frontal shield block for Shield Kin
    if (this.type === EnemyType.SHIELD && sourceX !== null && sourceY !== null && this.shieldOpenTimer <= 0) {
      const bulletAngle = Math.atan2(sourceY - this.y, sourceX - this.x);
      let diff = Math.abs(bulletAngle - this.aimAngle);
      while (diff > Math.PI) diff = Math.abs(diff - Math.PI * 2);

      // If bullet is coming from the front (within ~65 degrees of facing direction)
      if (diff < 1.15) {
        this.flashTimer = 0.08;
        return 0; // Completely absorbed by shield!
      }
    }

    // Apply knockback impulse
    if (sourceX !== null && sourceY !== null && knockback > 0) {
      const kdx = this.x - sourceX;
      const kdy = this.y - sourceY;
      const kdist = Math.hypot(kdx, kdy) || 1;
      this.vx += (kdx / kdist) * knockback;
      this.vy += (kdy / kdist) * knockback;
    }

    return super.takeDamage(amount);
  }

  // Smart Obstacle Steering: prevents enemies from getting stuck on pillars and room walls
  getSteeredMove(targetX, targetY, baseSpeed, room, strafeOffset = 0) {
    let desiredX = targetX - this.x;
    let desiredY = targetY - this.y;
    let dDist = Math.hypot(desiredX, desiredY) || 1;
    desiredX /= dDist;
    desiredY /= dDist;

    // Apply strafe perpendicular to target direction
    if (strafeOffset !== 0) {
      const perpX = -desiredY * strafeOffset;
      const perpY = desiredX * strafeOffset;
      desiredX += perpX * 0.65;
      desiredY += perpY * 0.65;
      const nLen = Math.hypot(desiredX, desiredY) || 1;
      desiredX /= nLen;
      desiredY /= nLen;
    }

    // Pillar Avoidance Whiskers
    if (room && room.pillars) {
      for (const p of room.pillars) {
        const pdx = this.x - p.x;
        const pdy = this.y - p.y;
        const pDist = Math.hypot(pdx, pdy);
        const dangerDist = this.radius + p.radius + 32;

        if (pDist < dangerDist && pDist > 0.001) {
          // Tangential push around pillar
          const nx = pdx / pDist;
          const ny = pdy / pDist;
          const strength = (dangerDist - pDist) / dangerDist;
          desiredX += nx * strength * 2.2;
          desiredY += ny * strength * 2.2;
        }
      }
    }

    // Room Wall Avoidance Whiskers
    if (room) {
      const pad = 50;
      if (this.x < room.x + pad) desiredX += 1.5;
      if (this.x > room.x + room.width - pad) desiredX -= 1.5;
      if (this.y < room.y + pad) desiredY += 1.5;
      if (this.y > room.y + room.height - pad) desiredY -= 1.5;
    }

    const finalLen = Math.hypot(desiredX, desiredY) || 1;
    return {
      vx: (desiredX / finalLen) * baseSpeed,
      vy: (desiredY / finalLen) * baseSpeed
    };
  }

  update(dt, player, bullets, audio, particles, room = null) {
    if (this.isDead || !player || player.isDead) return;

    this.stateTimer += dt;
    this.strafeTimer -= dt;
    if (this.strafeTimer <= 0) {
      this.strafeDir = -this.strafeDir;
      this.strafeTimer = 1.5 + Math.random() * 2.0;
    }

    const distToPlayer = Math.hypot(player.x - this.x, player.y - this.y);

    // Aim towards player unless locked by sniper telegraph
    if (!this.laserLocked) {
      this.aimAngle = Math.atan2(player.y - this.y, player.x - this.x);
    }

    // AI Behaviors by Enemy Type
    switch (this.type) {
      case EnemyType.PISTOL:
        this.updatePistol(dt, player, distToPlayer, bullets, audio, particles, room);
        break;
      case EnemyType.SMG:
        this.updateSMG(dt, player, distToPlayer, bullets, audio, room);
        break;
      case EnemyType.SNIPER:
        this.updateSniper(dt, player, distToPlayer, bullets, audio, room);
        break;
      case EnemyType.BAZOOKA:
        this.updateBazooka(dt, player, distToPlayer, bullets, audio, particles, room);
        break;
      case EnemyType.GATLING:
        this.updateGatling(dt, player, distToPlayer, bullets, audio, particles, room);
        break;
      case EnemyType.MAGE:
        this.updateMage(dt, player, distToPlayer, bullets, audio, particles, room);
        break;
      case EnemyType.BOMBER:
        this.updateBomber(dt, player, distToPlayer, bullets, audio, particles, room);
        break;
      case EnemyType.SHIELD:
        this.updateShield(dt, player, distToPlayer, bullets, audio, room);
        break;
      case EnemyType.SLIME:
        this.updateSlime(dt, player, distToPlayer, bullets, audio, particles, room);
        break;
    }

    // Smooth velocity interpolation towards target velocity (silky smooth Gungeon movement)
    const accelRate = this.isWindingUp ? 10.0 : 6.0;
    this.vx += (this.targetVx - this.vx) * Math.min(1.0, accelRate * dt);
    this.vy += (this.targetVy - this.vy) * Math.min(1.0, accelRate * dt);

    const speed = Math.hypot(this.vx, this.vy);
    if (speed > 8) {
      this.walkTimer += dt * (speed * 0.08);
    }

    this.updatePhysics(dt);
  }

  // 1. Pistol Kin: Bullet Kin style - tactical peek & shoot, telegraphs amber windup, 30% revenge shot on death
  updatePistol(dt, player, dist, bullets, audio, particles, room) {
    const idealMin = 170;
    const idealMax = 270;

    // Tactical positioning with pillar navigation
    if (dist > idealMax) {
      const move = this.getSteeredMove(player.x, player.y, 115, room, this.strafeDir * 0.4);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else if (dist < idealMin) {
      // Back off smoothly
      const awayX = this.x - Math.cos(this.aimAngle) * 200;
      const awayY = this.y - Math.sin(this.aimAngle) * 200;
      const move = this.getSteeredMove(awayX, awayY, 95, room, this.strafeDir * 0.6);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else {
      // Circle strafe in ideal range
      const move = this.getSteeredMove(player.x, player.y, 50, room, this.strafeDir * 1.0);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    }

    if (this.isWindingUp) {
      this.targetVx *= 0.1;
      this.targetVy *= 0.1;
    }

    this.shootTimer -= dt;

    // Telegraph wind-up (0.24s before shot)
    if (this.shootTimer <= 0.24 && !this.isWindingUp) {
      this.isWindingUp = true;
      if (audio) audio.playEnemyTelegraph();
    }

    if (this.shootTimer <= 0) {
      this.isWindingUp = false;
      this.shootTimer = 1.3 + Math.random() * 0.6;
      const bSpeed = 390;

      bullets.push(new Bullet({
        x: this.x + Math.cos(this.aimAngle) * 16,
        y: this.y + Math.sin(this.aimAngle) * 16,
        vx: Math.cos(this.aimAngle) * bSpeed,
        vy: Math.sin(this.aimAngle) * bSpeed,
        damage: 1,
        radius: 6,
        isPlayer: false,
        color: '#ff3344',
        type: 'enemy_pistol'
      }));

      if (audio) audio.playShoot('pistol');
    }
  }

  // 2. SMG Sprayer: Strafes rapidly while firing tight 4-round bursts
  updateSMG(dt, player, dist, bullets, audio, room) {
    const idealMin = 150;
    const idealMax = 240;

    if (dist > idealMax) {
      const move = this.getSteeredMove(player.x, player.y, 135, room, this.strafeDir * 0.5);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else if (dist < idealMin) {
      const awayX = this.x - Math.cos(this.aimAngle) * 200;
      const awayY = this.y - Math.sin(this.aimAngle) * 200;
      const move = this.getSteeredMove(awayX, awayY, 110, room, this.strafeDir * 0.8);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else {
      const move = this.getSteeredMove(player.x, player.y, 75, room, this.strafeDir * 1.0);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    }

    if (this.burstRemaining > 0) {
      // Slow down while bursting for dramatic effect
      this.targetVx *= 0.25;
      this.targetVy *= 0.25;

      this.burstTimer -= dt;
      if (this.burstTimer <= 0) {
        this.burstTimer = 0.08;
        this.burstRemaining--;
        const spread = (Math.random() - 0.5) * 0.22;
        const angle = this.aimAngle + spread;
        const bSpeed = 460;

        bullets.push(new Bullet({
          x: this.x + Math.cos(angle) * 16,
          y: this.y + Math.sin(angle) * 16,
          vx: Math.cos(angle) * bSpeed,
          vy: Math.sin(angle) * bSpeed,
          damage: 1,
          radius: 5,
          isPlayer: false,
          color: '#ff8800',
          type: 'enemy_smg'
        }));

        if (audio) audio.playShoot('smg');
      }
    } else {
      this.shootTimer -= dt;
      if (this.shootTimer <= 0.2 && !this.isWindingUp) {
        this.isWindingUp = true;
        if (audio) audio.playEnemyTelegraph();
      }

      if (this.shootTimer <= 0) {
        this.isWindingUp = false;
        this.shootTimer = 1.7 + Math.random() * 0.5;
        this.burstRemaining = 4;
        this.burstTimer = 0.04;
      }
    }
  }

  // 3. Sniper Deadeye: Long-range sniper. Tracks with laser -> Laser LOCKS for 0.28s -> Heavy shot!
  updateSniper(dt, player, dist, bullets, audio, room) {
    const idealDist = 400;
    if (dist < idealDist) {
      const awayX = this.x - Math.cos(this.aimAngle) * 250;
      const awayY = this.y - Math.sin(this.aimAngle) * 250;
      const move = this.getSteeredMove(awayX, awayY, 85, room);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else {
      // Strafe slightly while at range
      const move = this.getSteeredMove(player.x, player.y, 30, room, this.strafeDir * 0.8);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    }
    // Freeze completely when laser is locked
    if (this.laserLocked) {
      this.targetVx = 0;
      this.targetVy = 0;
    }

    this.shootTimer -= dt;

    // Laser tracking starts 1.3s before shot
    if (this.shootTimer <= 1.3) {
      this.isAimingLaser = true;
    }

    // CRITICAL GUNGEON MECHANIC: At 0.28s, laser LOCKS IN PLACE!
    if (this.shootTimer <= 0.28 && !this.laserLocked) {
      this.laserLocked = true;
      this.lockedLaserAngle = this.aimAngle;
      this.isWindingUp = true;
      if (audio) audio.playEnemyTelegraph();
    }

    if (this.shootTimer <= 0) {
      this.shootTimer = 3.3;
      this.isAimingLaser = false;
      this.laserLocked = false;
      this.isWindingUp = false;

      const fireAngle = this.lockedLaserAngle || this.aimAngle;
      const bSpeed = 1000;

      bullets.push(new Bullet({
        x: this.x + Math.cos(fireAngle) * 20,
        y: this.y + Math.sin(fireAngle) * 20,
        vx: Math.cos(fireAngle) * bSpeed,
        vy: Math.sin(fireAngle) * bSpeed,
        damage: 1,
        radius: 7,
        isPlayer: false,
        color: '#ff0033',
        type: 'sniper'
      }));

      if (audio) audio.playShoot('sniper');
    }
  }

  // 4. Bazooka Bombardier: Fires slow homing/detonating rocket that blasts into 8 shrapnel bullets
  updateBazooka(dt, player, dist, bullets, audio, particles, room) {
    if (dist > 320) {
      const move = this.getSteeredMove(player.x, player.y, 65, room, this.strafeDir * 0.3);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else if (dist < 200) {
      const awayX = this.x - Math.cos(this.aimAngle) * 220;
      const awayY = this.y - Math.sin(this.aimAngle) * 220;
      const move = this.getSteeredMove(awayX, awayY, 70, room);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else {
      // Strafe side to side at ideal distance
      const move = this.getSteeredMove(player.x, player.y, 40, room, this.strafeDir * 1.2);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    }
    if (this.isWindingUp) {
      this.targetVx = 0;
      this.targetVy = 0;
    }

    this.shootTimer -= dt;

    if (this.shootTimer <= 0.35 && !this.isWindingUp) {
      this.isWindingUp = true;
      if (audio) audio.playEnemyTelegraph();
      if (particles) particles.createDust(this.x, this.y, 5);
    }

    if (this.shootTimer <= 0) {
      this.isWindingUp = false;
      this.shootTimer = 3.2 + Math.random() * 0.8;
      const bSpeed = 250;

      const rocket = new Bullet({
        x: this.x + Math.cos(this.aimAngle) * 20,
        y: this.y + Math.sin(this.aimAngle) * 20,
        vx: Math.cos(this.aimAngle) * bSpeed,
        vy: Math.sin(this.aimAngle) * bSpeed,
        damage: 1,
        radius: 9,
        isPlayer: false,
        color: '#ff4400',
        type: 'enemy_rocket',
        lifetime: 2.4
      });

      rocket.onDetonate = (spawnList) => {
        if (particles) particles.createExplosion(rocket.x, rocket.y, 55);
        if (audio) audio.playExplosion();
        for (let i = 0; i < 8; i++) {
          const sAngle = (i / 8) * Math.PI * 2;
          spawnList.push(new Bullet({
            x: rocket.x,
            y: rocket.y,
            vx: Math.cos(sAngle) * 260,
            vy: Math.sin(sAngle) * 260,
            damage: 1,
            radius: 5,
            isPlayer: false,
            color: '#ff7700',
            type: 'enemy_pistol'
          }));
        }
      };

      bullets.push(rocket);
      if (audio) audio.playShoot('rocket');
    }
  }

  // 5. Heavy Gatling Behemoth: Barrel spin-up windup, then sustained bullet hell cone
  updateGatling(dt, player, dist, bullets, audio, particles, room) {
    if (this.isWindingUp || this.gatlingStreamTimer > 0) {
      // Slow heavy march while firing
      const move = this.getSteeredMove(player.x, player.y, 28, room);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else {
      const move = this.getSteeredMove(player.x, player.y, 55, room, this.strafeDir * 0.4);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    }

    if (this.gatlingStreamTimer > 0) {
      this.gatlingStreamTimer -= dt;
      if (Math.random() < 0.4) {
        const sweepAngle = this.aimAngle + (Math.sin(this.stateTimer * 7) * 0.45);
        bullets.push(new Bullet({
          x: this.x + Math.cos(sweepAngle) * 24,
          y: this.y + Math.sin(sweepAngle) * 24,
          vx: Math.cos(sweepAngle) * 390,
          vy: Math.sin(sweepAngle) * 390,
          damage: 1,
          radius: 5,
          isPlayer: false,
          color: '#ff2255',
          type: 'enemy_smg'
        }));
        if (audio && Math.random() < 0.35) audio.playShoot('smg');
      }
    } else {
      this.shootTimer -= dt;
      if (this.shootTimer <= 0.5 && !this.isWindingUp) {
        this.isWindingUp = true;
        if (audio) audio.playEnemyTelegraph();
        if (particles) particles.createHitSparks(this.x + Math.cos(this.aimAngle) * 20, this.y + Math.sin(this.aimAngle) * 20, '#ffaa00');
      }

      if (this.shootTimer <= 0) {
        this.isWindingUp = false;
        this.shootTimer = 3.6;
        this.gatlingStreamTimer = 1.8;
      }
    }
  }

  // 6. Arcane Mage: Floats, emergency teleports when rushed, casts 6-bolt spiral ring
  updateMage(dt, player, dist, bullets, audio, particles, room) {
    // Smooth harmonic float orbit around aimAngle perpendicular
    const floatAngle = this.aimAngle + Math.PI / 2 + Math.sin(this.stateTimer * 2.2) * 0.6;
    const floatSpeed = 55;

    if (dist > 300) {
      const move = this.getSteeredMove(player.x, player.y, 80, room);
      this.targetVx = move.vx + Math.cos(floatAngle) * floatSpeed * 0.4;
      this.targetVy = move.vy + Math.sin(floatAngle) * floatSpeed * 0.4;
    } else if (dist < 170) {
      const awayX = this.x - Math.cos(this.aimAngle) * 200;
      const awayY = this.y - Math.sin(this.aimAngle) * 200;
      const move = this.getSteeredMove(awayX, awayY, 90, room);
      this.targetVx = move.vx + Math.cos(floatAngle) * floatSpeed * 0.6;
      this.targetVy = move.vy + Math.sin(floatAngle) * floatSpeed * 0.6;
    } else {
      // Drift in smooth arcs
      this.targetVx = Math.cos(floatAngle) * floatSpeed;
      this.targetVy = Math.sin(floatAngle) * floatSpeed;
    }
    if (this.isWindingUp) {
      this.targetVx *= 0.05;
      this.targetVy *= 0.05;
    }

    // Emergency Teleport if player gets too close
    this.teleportCooldown -= dt;
    if (dist < 115 && this.teleportCooldown <= 0) {
      this.teleportCooldown = 3.5;
      if (particles) particles.createShockwave(this.x, this.y, 80, '#c084fc', 220);
      if (audio) audio.playDodgeRoll();

      const tpAngle = this.aimAngle + Math.PI + (Math.random() - 0.5) * 0.8;
      this.x += Math.cos(tpAngle) * 230;
      this.y += Math.sin(tpAngle) * 230;
      if (particles) particles.createShockwave(this.x, this.y, 60, '#c084fc', 200);
    }

    // Cast Arcane Spiral Rings
    this.shootTimer -= dt;
    if (this.shootTimer <= 0.35 && !this.isWindingUp) {
      this.isWindingUp = true;
      if (audio) audio.playEnemyTelegraph();
    }

    if (this.shootTimer <= 0) {
      this.isWindingUp = false;
      this.shootTimer = 2.6 + Math.random() * 0.6;
      if (audio) audio.playShoot('plasma');

      // 6-directional spiral ring
      for (let i = 0; i < 6; i++) {
        const spiralAngle = this.aimAngle + (i / 6) * Math.PI * 2;
        const bSpeed = 240;
        bullets.push(new Bullet({
          x: this.x + Math.cos(spiralAngle) * 18,
          y: this.y + Math.sin(spiralAngle) * 18,
          vx: Math.cos(spiralAngle) * bSpeed,
          vy: Math.sin(spiralAngle) * bSpeed,
          damage: 1,
          radius: 6,
          isPlayer: false,
          color: '#c084fc',
          type: 'enemy_mage',
          homing: true,
          target: player,
          lifetime: 3.0
        }));
      }
    }
  }

  // 7. Bomber Kin: Ticking fuse, fast sprint, lunges and detonates
  updateBomber(dt, player, dist, bullets, audio, particles, room) {
    // Erratic zigzag charge - speed increases as fuse burns
    const fuseRatio = Math.max(0, Math.min(1, (this.fuseTimer || 4.0) / 4.0));
    const chargeSpeed = 170 + (1 - fuseRatio) * 80;
    const zigzag = Math.sin(this.stateTimer * 8) * 0.45;
    const move = this.getSteeredMove(player.x, player.y, chargeSpeed, room, zigzag);
    this.targetVx = move.vx;
    this.targetVy = move.vy;

    this.fuseTimer -= dt;
    this.isTicking = true;

    // Sparks from fuse
    if (particles && Math.random() < 0.45) {
      particles.createHitSparks(this.x, this.y - 14, '#f59e0b');
    }

    // Detonate when close or when fuse runs out
    if (dist < (this.radius + player.radius + 8) || this.fuseTimer <= 0) {
      this.detonateBomber(player, bullets, audio, particles);
    }
  }

  detonateBomber(player, bullets, audio, particles) {
    if (this.isDead) return;
    this.isDead = true;

    if (particles) {
      particles.createExplosion(this.x, this.y, 80);
      particles.createShockwave(this.x, this.y, 150, '#ff4400', 360);
    }
    if (audio) audio.playExplosion();

    // Damage player directly if close and not rolling
    const distToPlayer = Math.hypot(player.x - this.x, player.y - this.y);
    if (distToPlayer < 80 && !player.isRolling && !player.isInvulnerable) {
      player.takeDamage(1);
      audio.playPlayerHurt();
      if (particles) particles.createBlood(player.x, player.y, 14);
    }

    // Disperse 8 shrapnel bullets in a ring
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      bullets.push(new Bullet({
        x: this.x,
        y: this.y,
        vx: Math.cos(a) * 270,
        vy: Math.sin(a) * 270,
        damage: 1,
        radius: 5,
        isPlayer: false,
        color: '#ff5500',
        type: 'enemy_pistol'
      }));
    }
  }

  // 8. Shield Phalanx: Tower shield blocks frontal shots. Lowers shield to fire 5-pellet shotgun blast!
  updateShield(dt, player, dist, bullets, audio, room) {
    if (this.shieldOpenTimer > 0) {
      this.shieldOpenTimer -= dt;
    }

    if (dist > 180) {
      const move = this.getSteeredMove(player.x, player.y, 75, room, this.strafeDir * 0.3);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else if (dist < 110) {
      const awayX = this.x - Math.cos(this.aimAngle) * 150;
      const awayY = this.y - Math.sin(this.aimAngle) * 150;
      const move = this.getSteeredMove(awayX, awayY, 60, room);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else {
      // Slow tactical strafe at close range
      const move = this.getSteeredMove(player.x, player.y, 40, room, this.strafeDir * 0.7);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    }
    // Freeze to fire (dramatic pause)
    if (this.shieldOpenTimer > 0.3) {
      this.targetVx = 0;
      this.targetVy = 0;
    }

    this.shootTimer -= dt;

    if (this.shootTimer <= 0.35 && !this.isWindingUp) {
      this.isWindingUp = true;
      if (audio) audio.playEnemyTelegraph();
    }

    if (this.shootTimer <= 0) {
      this.isWindingUp = false;
      this.shootTimer = 2.8 + Math.random() * 0.6;
      this.shieldOpenTimer = 0.55; // Lower shield to shoot (vulnerability window!)

      if (audio) audio.playShoot('shotgun');

      // Fire 5-pellet shotgun fan
      for (let i = -2; i <= 2; i++) {
        const a = this.aimAngle + i * 0.16;
        bullets.push(new Bullet({
          x: this.x + Math.cos(a) * 18,
          y: this.y + Math.sin(a) * 18,
          vx: Math.cos(a) * 370,
          vy: Math.sin(a) * 370,
          damage: 1,
          radius: 5,
          isPlayer: false,
          color: '#e2e8f0',
          type: 'enemy_smg'
        }));
      }
    }
  }

  // 9. Toxic Slime: Squirms and spits poisonous globs
  updateSlime(dt, player, dist, bullets, audio, particles, room) {
    this.squishTimer += dt * 5;
    // Organic undulating movement
    const slimeWobble = Math.sin(this.squishTimer) * 0.7;

    if (dist > 190) {
      const move = this.getSteeredMove(player.x, player.y, 90, room, slimeWobble);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else if (dist < 130) {
      const awayX = this.x - Math.cos(this.aimAngle) * 150;
      const awayY = this.y - Math.sin(this.aimAngle) * 150;
      const move = this.getSteeredMove(awayX, awayY, 70, room, slimeWobble * 0.5);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    } else {
      // Pulse in & out rhythmically when at range
      const pulseSpeed = Math.sin(this.squishTimer * 0.6) * 50;
      const move = this.getSteeredMove(player.x, player.y, pulseSpeed, room, slimeWobble);
      this.targetVx = move.vx;
      this.targetVy = move.vy;
    }

    this.shootTimer -= dt;

    if (this.shootTimer <= 0.3 && !this.isWindingUp) {
      this.isWindingUp = true;
      if (audio) audio.playEnemyTelegraph();
    }

    if (this.shootTimer <= 0) {
      this.isWindingUp = false;
      this.shootTimer = 2.4 + Math.random() * 0.5;
      if (audio) audio.playShoot('plasma');

      const bSpeed = 290;
      bullets.push(new Bullet({
        x: this.x + Math.cos(this.aimAngle) * 16,
        y: this.y + Math.sin(this.aimAngle) * 16,
        vx: Math.cos(this.aimAngle) * bSpeed,
        vy: Math.sin(this.aimAngle) * bSpeed,
        damage: 1,
        radius: 8,
        isPlayer: false,
        color: '#10b981',
        type: 'enemy_acid',
        lifetime: 2.6
      }));
    }
  }

  render(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);

    // Hit flash (white silhouette when receiving damage)
    if (this.flashTimer > 0) {
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, 0, this.radius + 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      return;
    }

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.ellipse(0, this.radius - 2, this.radius * 0.9, this.radius * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();

    const isFacingLeft = Math.cos(this.aimAngle) < 0;

    // Telegraphing indicator glow
    if (this.isWindingUp) {
      ctx.strokeStyle = '#ffaa00';
      ctx.lineWidth = 2;
      ctx.shadowBlur = 14;
      ctx.shadowColor = '#ffaa00';
      ctx.beginPath();
      ctx.arc(0, 0, this.radius + 4, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    // Body rendering by enemy type
    switch (this.type) {
      case EnemyType.PISTOL:
        // Bullet kin shape (bronze bullet shell with eyes)
        ctx.fillStyle = '#d97706';
        ctx.beginPath();
        ctx.arc(0, -4, 12, Math.PI, 0);
        ctx.lineTo(12, 10);
        ctx.lineTo(-12, 10);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#fef3c7';
        ctx.fillRect(-12, 8, 24, 4);

        // Eyes (glow bright during windup)
        ctx.fillStyle = this.isWindingUp ? '#ffea00' : '#ffffff';
        const pEyeX = isFacingLeft ? -4 : 2;
        ctx.fillRect(pEyeX, -6, 4, 6);
        ctx.fillRect(pEyeX + (isFacingLeft ? -5 : 5), -6, 4, 6);
        ctx.fillStyle = '#000';
        ctx.fillRect(pEyeX + (isFacingLeft ? 0 : 2), -4, 2, 3);
        ctx.fillRect(pEyeX + (isFacingLeft ? -5 : 7), -4, 2, 3);
        break;

      case EnemyType.SMG:
        ctx.fillStyle = '#1e3a8a';
        ctx.beginPath();
        ctx.arc(0, -4, 13, Math.PI, 0);
        ctx.lineTo(13, 10);
        ctx.lineTo(-13, 10);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#dc2626';
        ctx.fillRect(-13, -7, 26, 5);

        ctx.fillStyle = this.isWindingUp ? '#ff4400' : '#fff';
        const sEyeX = isFacingLeft ? -3 : 2;
        ctx.fillRect(sEyeX, -2, 4, 4);
        ctx.fillRect(sEyeX + (isFacingLeft ? -5 : 5), -2, 4, 4);
        break;

      case EnemyType.SNIPER:
        ctx.fillStyle = '#7f1d1d';
        ctx.beginPath();
        ctx.arc(0, -2, 13, 0, Math.PI * 2);
        ctx.fill();

        // Glowing red optic during lock, cyan when idle
        ctx.fillStyle = this.laserLocked ? '#ff0033' : '#00ffff';
        ctx.shadowBlur = this.laserLocked ? 12 : 6;
        ctx.shadowColor = this.laserLocked ? '#ff0033' : '#00ffff';
        ctx.beginPath();
        ctx.arc(isFacingLeft ? -5 : 5, -3, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        break;

      case EnemyType.BAZOOKA:
        ctx.fillStyle = '#166534';
        ctx.fillRect(-16, -14, 32, 26);
        ctx.fillStyle = '#14532d';
        ctx.fillRect(-18, -4, 36, 10);
        ctx.fillStyle = '#facc15';
        ctx.fillRect(-8, -10, 16, 4);
        break;

      case EnemyType.GATLING:
        ctx.fillStyle = '#374151';
        ctx.beginPath();
        ctx.arc(0, 0, 20, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#1f2937';
        ctx.fillRect(-14, -6, 28, 14);

        ctx.fillStyle = '#ff0033';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#ff0033';
        ctx.fillRect(-10, -6, 20, 4);
        ctx.shadowBlur = 0;
        break;

      case EnemyType.MAGE:
        ctx.fillStyle = '#4c1d95';
        ctx.beginPath();
        ctx.arc(0, -5, 13, Math.PI, 0);
        ctx.lineTo(14, 12);
        ctx.lineTo(-14, 12);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#7c3aed';
        ctx.beginPath();
        ctx.arc(0, -5, 14, Math.PI * 0.9, Math.PI * 0.1, true);
        ctx.lineWidth = 3;
        ctx.strokeStyle = '#c084fc';
        ctx.stroke();

        ctx.fillStyle = '#e879f9';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#e879f9';
        const mEyeX = isFacingLeft ? -5 : 1;
        ctx.fillRect(mEyeX, -6, 4, 4);
        ctx.fillRect(mEyeX + (isFacingLeft ? -5 : 6), -6, 4, 4);
        ctx.shadowBlur = 0;

        const orbAngle = this.stateTimer * 3.5;
        const orbX = Math.cos(orbAngle) * 22;
        const orbY = Math.sin(orbAngle) * 8 - 4;
        ctx.fillStyle = '#c084fc';
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#c084fc';
        ctx.beginPath();
        ctx.arc(orbX, orbY, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        break;

      case EnemyType.BOMBER:
        const isBlinking = (Math.sin(this.stateTimer * 16) > 0);
        ctx.fillStyle = isBlinking ? '#ff1100' : '#b91c1c';
        ctx.beginPath();
        ctx.arc(0, 0, 13, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#fbbf24';
        ctx.fillRect(-10, -3, 20, 6);

        ctx.strokeStyle = '#78350f';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(0, -12);
        ctx.quadraticCurveTo(6, -18, 4, -22);
        ctx.stroke();

        ctx.fillStyle = '#facc15';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#f59e0b';
        ctx.beginPath();
        ctx.arc(4, -22, 3.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        ctx.fillStyle = '#ffffff';
        ctx.fillRect(isFacingLeft ? -6 : 1, -4, 5, 5);
        ctx.fillRect(isFacingLeft ? 0 : 7, -4, 5, 5);
        ctx.fillStyle = '#000000';
        ctx.fillRect(isFacingLeft ? -4 : 3, -3, 2, 2);
        ctx.fillRect(isFacingLeft ? 2 : 9, -3, 2, 2);
        break;

      case EnemyType.SHIELD:
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.arc(0, 0, 14, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(-8, -12, 16, 5);

        // Tower Shield in front
        ctx.save();
        ctx.rotate(this.aimAngle);
        ctx.fillStyle = this.shieldOpenTimer > 0 ? '#64748b' : '#0284c7';
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 2.5;

        ctx.beginPath();
        ctx.roundRect(10, -16, 8, 32, 4);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(14, 0, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
        break;

      case EnemyType.SLIME:
        const squishX = 1 + Math.sin(this.squishTimer) * 0.15;
        const squishY = 1 - Math.sin(this.squishTimer) * 0.15;
        ctx.scale(squishX, squishY);

        ctx.fillStyle = 'rgba(16, 185, 129, 0.85)';
        ctx.beginPath();
        ctx.arc(0, 0, 15, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#34d399';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = '#a7f3d0';
        ctx.beginPath();
        ctx.arc(isFacingLeft ? -4 : 4, -2, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#064e3b';
        ctx.fillRect(isFacingLeft ? -6 : 2, -3, 3, 3);
        ctx.fillRect(isFacingLeft ? 0 : 8, -3, 3, 3);
        break;
    }

    // Floating Telegraph Warning Exclamation (!)
    if (this.isWindingUp) {
      ctx.font = "bold 13px 'Press Start 2P', monospace";
      ctx.fillStyle = '#ffcc00';
      ctx.textAlign = 'center';
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#ffcc00';
      ctx.fillText('!', 0, -this.radius - 16);
      ctx.shadowBlur = 0;
    }

    // Health bar above enemy head (if damaged)
    if (this.health < this.maxHealth) {
      const pct = this.health / this.maxHealth;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(-16, -this.radius - 12, 32, 5);
      ctx.fillStyle = '#ff3344';
      ctx.fillRect(-15, -this.radius - 11, 30 * pct, 3);
    }

    ctx.restore();

    // Render Sniper Laser Telegraph in World coordinates (Enter the Gungeon style)
    if (this.type === EnemyType.SNIPER && this.isAimingLaser) {
      ctx.save();
      const laserAngle = this.laserLocked ? this.lockedLaserAngle : this.aimAngle;
      ctx.beginPath();
      ctx.moveTo(this.x, this.y);
      ctx.lineTo(this.x + Math.cos(laserAngle) * 650, this.y + Math.sin(laserAngle) * 650);

      if (this.laserLocked) {
        // Locked laser: bright solid red with heavy glow (Dodge roll window!)
        ctx.strokeStyle = '#ff0033';
        ctx.lineWidth = 3;
        ctx.shadowBlur = 12;
        ctx.shadowColor = '#ff0033';
        ctx.setLineDash([]);
      } else {
        // Tracking laser: dashed faint red
        ctx.strokeStyle = 'rgba(255, 0, 50, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([6, 6]);
      }
      ctx.stroke();
      ctx.restore();
    }
  }
}

// Spawner helper according to floor progression
export function spawnEnemiesForFloor(floorNumber, room) {
  const enemies = [];
  const padding = 120;
  const count = 3 + floorNumber; // 4 enemies on floor 1, up to 10 on floor 7

  const availableTypes = [EnemyType.PISTOL];

  if (floorNumber === 2) {
    availableTypes.push(EnemyType.SMG, EnemyType.SNIPER, EnemyType.BOMBER);
  } else if (floorNumber === 3) {
    availableTypes.push(EnemyType.SMG, EnemyType.SNIPER, EnemyType.BAZOOKA, EnemyType.BOMBER, EnemyType.SLIME);
  } else if (floorNumber === 4) {
    availableTypes.push(EnemyType.SMG, EnemyType.SNIPER, EnemyType.BAZOOKA, EnemyType.GATLING, EnemyType.SHIELD, EnemyType.MAGE);
  } else if (floorNumber === 5) {
    availableTypes.push(EnemyType.SNIPER, EnemyType.BAZOOKA, EnemyType.GATLING, EnemyType.SHIELD, EnemyType.MAGE, EnemyType.BOMBER);
  } else if (floorNumber === 6) {
    availableTypes.push(EnemyType.BAZOOKA, EnemyType.GATLING, EnemyType.SHIELD, EnemyType.MAGE, EnemyType.BOMBER, EnemyType.SLIME);
  } else if (floorNumber >= 7) {
    availableTypes.push(EnemyType.GATLING, EnemyType.BAZOOKA, EnemyType.SHIELD, EnemyType.MAGE, EnemyType.SNIPER, EnemyType.BOMBER, EnemyType.SLIME);
  }

  for (let i = 0; i < count; i++) {
    const rx = room.x + padding + Math.random() * (room.width - padding * 2);
    const ry = room.y + padding + Math.random() * (room.height - padding * 2);

    const type = availableTypes[Math.floor(Math.random() * availableTypes.length)];
    enemies.push(new Enemy(rx, ry, type));
  }

  return enemies;
}
