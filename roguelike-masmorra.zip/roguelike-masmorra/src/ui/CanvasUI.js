// 100% Pure JavaScript Canvas UI Engine for HUD, Menus, Boss Bar, Minimap, and Crosshair
import { RoomType } from '../dungeon/Room.js';

export class CanvasUI {
  constructor() {
    this.buttons = []; // List of active clickable buttons for the current screen
    this.toast = null; // { text, timer, maxTimer }
    this.particles = []; // UI particles for title screen embers
    this.initTitleEmbers();
  }

  initTitleEmbers() {
    for (let i = 0; i < 40; i++) {
      this.particles.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 20,
        vy: -20 - Math.random() * 40,
        size: 2 + Math.random() * 3,
        alpha: 0.2 + Math.random() * 0.6,
        color: Math.random() < 0.5 ? '#ffaa00' : '#ff3344'
      });
    }
  }

  updateTitleEmbers(dt, width, height) {
    this.particles.forEach(p => {
      p.y += p.vy * dt;
      p.x += p.vx * dt;
      if (p.y < -10) {
        p.y = height + 10;
        p.x = Math.random() * width;
      }
    });
  }

  showToast(text, duration = 2.0) {
    this.toast = {
      text,
      timer: duration,
      maxTimer: duration
    };
  }

  updateToast(dt) {
    if (this.toast) {
      this.toast.timer -= dt;
      if (this.toast.timer <= 0) {
        this.toast = null;
      }
    }
  }

  // --- BUTTON MANAGEMENT ---
  clearButtons() {
    this.buttons = [];
  }

  registerButton(id, x, y, width, height, text, onClick, isGold = false) {
    this.buttons.push({
      id,
      x,
      y,
      width,
      height,
      text,
      onClick,
      isGold,
      isHovered: false
    });
  }

  handleMouseMove(mouseX, mouseY) {
    this.buttons.forEach(btn => {
      btn.isHovered = mouseX >= btn.x && mouseX <= btn.x + btn.width &&
                      mouseY >= btn.y && mouseY <= btn.y + btn.height;
    });
  }

  handleClick(mouseX, mouseY, audio) {
    for (const btn of this.buttons) {
      if (mouseX >= btn.x && mouseX <= btn.x + btn.width &&
          mouseY >= btn.y && mouseY <= btn.y + btn.height) {
        if (audio) audio.playHit();
        btn.onClick();
        return true;
      }
    }
    return false;
  }

  renderButton(ctx, btn) {
    ctx.save();
    const isHov = btn.isHovered;

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.fillRect(btn.x + 3, btn.y + 4, btn.width, btn.height);

    // Button body
    const baseColor = btn.isGold ? '#ffaa00' : '#ffcc00';
    const hovColor = btn.isGold ? '#ffc44d' : '#ffe066';
    ctx.fillStyle = isHov ? hovColor : baseColor;
    ctx.fillRect(btn.x, btn.y, btn.width, btn.height);

    // Bevel highlights & border
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.strokeRect(btn.x, btn.y, btn.width, btn.height);

    // Dark bottom edge (arcade depth)
    ctx.fillStyle = btn.isGold ? '#b37700' : '#b38f00';
    ctx.fillRect(btn.x, btn.y + btn.height - 4, btn.width, 4);

    // Button Text
    ctx.font = "bold 13px 'Press Start 2P', monospace";
    ctx.fillStyle = '#0a0a0f';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(btn.text, btn.x + btn.width / 2, btn.y + btn.height / 2 - 1);

    ctx.restore();
  }

  // --- CROSSHAIR ---
  drawCrosshair(ctx, mouseX, mouseY, isShooting) {
    ctx.save();
    ctx.translate(mouseX, mouseY);

    const size = isShooting ? 16 : 12;
    const gap = isShooting ? 8 : 5;

    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 2;
    ctx.shadowBlur = 8;
    ctx.shadowColor = '#ffcc00';

    // 4 prongs
    ctx.beginPath();
    // Top
    ctx.moveTo(0, -gap);
    ctx.lineTo(0, -size);
    // Bottom
    ctx.moveTo(0, gap);
    ctx.lineTo(0, size);
    // Left
    ctx.moveTo(-gap, 0);
    ctx.lineTo(-size, 0);
    // Right
    ctx.moveTo(gap, 0);
    ctx.lineTo(size, 0);
    ctx.stroke();

    // Center dot
    ctx.fillStyle = '#ff3344';
    ctx.beginPath();
    ctx.arc(0, 0, 2, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // --- IN-GAME HUD ---
  drawHUD(ctx, player, currentFloor, floorInfo, activeBoss, dungeon, currentRoom, interactionPrompt, bossDefeated) {
    if (!player) return;

    // 1. TOP-LEFT: HEARTS, BLANKS, KEYS, COINS
    ctx.save();
    const padX = 20;
    const padY = 20;

    // Background pill
    ctx.fillStyle = 'rgba(12, 14, 22, 0.85)';
    ctx.strokeStyle = 'rgba(255, 204, 0, 0.3)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(padX, padY, 230, 80, 8);
    ctx.fill();
    ctx.stroke();

    // Hearts (2 HP per heart container)
    const maxHearts = Math.ceil(player.maxHealth / 2);
    for (let i = 0; i < maxHearts; i++) {
      const hX = padX + 16 + i * 32;
      const hY = padY + 16;
      const heartHp = player.health - i * 2;

      this.drawHeart(ctx, hX, hY, heartHp);
    }

    // Sub-stats (Blanks, Keys, Coins)
    const statY = padY + 62;

    // Blanks
    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#00ddff';
    ctx.fillText('🛡️ Blanks:', padX + 14, statY);
    ctx.font = "bold 13px 'Press Start 2P', monospace";
    ctx.fillText(`x${player.blanks}`, padX + 80, statY - 1);
    ctx.font = "9px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.fillText('[Q]', padX + 110, statY - 1);

    // Coins
    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#ffaa00';
    ctx.fillText('🪙', padX + 155, statY);
    ctx.font = "bold 14px 'Press Start 2P', monospace";
    ctx.fillStyle = '#fff';
    ctx.fillText(`${player.coins}`, padX + 175, statY - 1);

    ctx.restore();

    // 2. TOP-RIGHT: FLOOR BADGE & MINIMAP
    ctx.save();
    const mmW = 140;
    const mmH = 140;
    const mmX = ctx.canvas.width - mmW - 20;
    const mmY = 56;

    // Floor title banner
    ctx.textAlign = 'right';
    ctx.font = "bold 12px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.fillText(`ANDAR ${currentFloor}`, ctx.canvas.width - 20, 28);
    ctx.font = "bold 14px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#9ca3af';
    ctx.fillText(floorInfo ? floorInfo.name : '', ctx.canvas.width - 20, 46);

    // Minimap Container
    ctx.fillStyle = 'rgba(9, 10, 18, 0.9)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(mmX, mmY, mmW, mmH, 6);
    ctx.fill();
    ctx.stroke();

    // Draw Minimap Content
    this.drawMinimap(ctx, mmX, mmY, mmW, mmH, dungeon, currentRoom, player);
    ctx.restore();

    // 3. BOTTOM-RIGHT: WEAPON & AMMO & ROLL COOLDOWN
    ctx.save();
    const wCardW = 240;
    const wCardH = 88;
    const wCardX = ctx.canvas.width - wCardW - 20;
    const wCardY = ctx.canvas.height - wCardH - 20;

    ctx.fillStyle = 'rgba(12, 14, 22, 0.9)';
    ctx.strokeStyle = 'rgba(255, 204, 0, 0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(wCardX, wCardY, wCardW, wCardH, 8);
    ctx.fill();
    ctx.stroke();

    const weapon = player.activeWeapon;

    // Weapon Icon Box
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 1.5;
    ctx.fillRect(wCardX + 10, wCardY + 10, 48, 48);
    ctx.strokeRect(wCardX + 10, wCardY + 10, 48, 48);

    ctx.font = "24px sans-serif";
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(weapon.emoji, wCardX + 34, wCardY + 34);

    // Weapon Name & Ammo
    ctx.textAlign = 'left';
    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#ffcc00';
    ctx.fillText(weapon.name, wCardX + 68, wCardY + 24);

    // Ammo Counter
    ctx.font = "bold 13px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffffff';
    const reserveText = weapon.def.maxAmmo === Infinity ? '∞' : String(weapon.reserveAmmo);
    ctx.fillText(`${weapon.currentClip} / ${reserveText}`, wCardX + 68, wCardY + 46);

    // Reloading indicator
    if (weapon.isReloading) {
      const pct = weapon.getReloadProgress();
      ctx.fillStyle = '#ff3344';
      ctx.font = "bold 8px 'Press Start 2P', monospace";
      ctx.fillText('RECARREGANDO...', wCardX + 68, wCardY + 60);

      ctx.fillStyle = '#222';
      ctx.fillRect(wCardX + 68, wCardY + 64, 150, 4);
      ctx.fillStyle = '#ffcc00';
      ctx.fillRect(wCardX + 68, wCardY + 64, 150 * pct, 4);
    }

    // Dodge Roll Cooldown Bar
    const rollY = wCardY + 70;
    ctx.font = "bold 11px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#9ca3af';
    ctx.fillText('ESQUIVA [ESPAÇO / BOTÃO DIR]', wCardX + 12, rollY + 4);

    const rollPct = player.cooldownTimer > 0 ? (1 - player.cooldownTimer / player.rollCooldown) : 1;
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(wCardX + 150, rollY - 3, 76, 7);
    ctx.fillStyle = '#00ddff';
    ctx.fillRect(wCardX + 150, rollY - 3, 76 * rollPct, 7);

    ctx.restore();

    // 4. TOP-CENTER: BOSS HEALTH BAR (When active)
    if (activeBoss && !activeBoss.isDead) {
      this.drawBossBar(ctx, activeBoss);
    } else if (bossDefeated) {
      // If Boss was defeated, draw prominent exit banner at top
      ctx.save();
      const bX = ctx.canvas.width / 2;
      const bY = 32;
      ctx.fillStyle = 'rgba(10, 24, 20, 0.9)';
      ctx.strokeStyle = '#00ffaa';
      ctx.lineWidth = 2;
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#00ffaa';
      ctx.beginPath();
      ctx.roundRect(bX - 220, bY - 16, 440, 36, 18);
      ctx.fill();
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.font = "bold 13px 'Rajdhani', sans-serif";
      ctx.fillStyle = '#00ffaa';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('▲ CÂMARA DO ELEVADOR ABERTA! SIGA PARA A SALA DE SAÍDA ▲', bX, bY + 2);
      ctx.restore();
    }

    // 5. CENTER TOAST MESSAGE (Floor cleared, etc.)
    if (this.toast) {
      ctx.save();
      const tX = ctx.canvas.width / 2;
      const tY = 120;
      ctx.font = "bold 14px 'Press Start 2P', monospace";
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffcc00';
      ctx.shadowBlur = 12;
      ctx.shadowColor = '#ffaa00';
      ctx.fillText(this.toast.text, tX, tY);
      ctx.restore();
    }

    // 6. INTERACTION PROMPT
    if (interactionPrompt) {
      ctx.save();
      const pX = ctx.canvas.width / 2;
      const pY = ctx.canvas.height - 90;

      ctx.fillStyle = 'rgba(10, 12, 20, 0.92)';
      ctx.strokeStyle = '#ffd700';
      ctx.lineWidth = 2.5;
      ctx.shadowBlur = 18;
      ctx.shadowColor = '#ffcc00';
      ctx.beginPath();
      ctx.roundRect(pX - 220, pY - 22, 440, 44, 22);
      ctx.fill();
      ctx.stroke();

      ctx.shadowBlur = 0;
      ctx.font = "bold 15px 'Rajdhani', sans-serif";
      ctx.fillStyle = '#ffea75';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(interactionPrompt, pX, pY);
      ctx.restore();
    }
  }

  drawHeart(ctx, x, y, hp) {
    ctx.save();
    ctx.translate(x, y);

    if (hp >= 2) {
      // Full Heart
      ctx.fillStyle = '#ff2244';
      ctx.shadowBlur = 6;
      ctx.shadowColor = '#ff2244';
      this.drawHeartPath(ctx);
      ctx.fill();
    } else if (hp === 1) {
      // Half Heart
      ctx.fillStyle = 'rgba(255, 34, 68, 0.2)';
      this.drawHeartPath(ctx);
      ctx.fill();

      // Left half solid
      ctx.save();
      ctx.beginPath();
      ctx.rect(-14, -14, 14, 28);
      ctx.clip();
      ctx.fillStyle = '#ff2244';
      this.drawHeartPath(ctx);
      ctx.fill();
      ctx.restore();
    } else {
      // Empty Heart outline
      ctx.fillStyle = 'rgba(40, 40, 50, 0.6)';
      this.drawHeartPath(ctx);
      ctx.fill();
      ctx.strokeStyle = '#555';
      ctx.lineWidth = 1.5;
      this.drawHeartPath(ctx);
      ctx.stroke();
    }

    ctx.restore();
  }

  drawHeartPath(ctx) {
    ctx.beginPath();
    ctx.moveTo(0, 5);
    ctx.bezierCurveTo(-12, -8, -14, -14, -6, -18);
    ctx.bezierCurveTo(0, -18, 0, -12, 0, -10);
    ctx.bezierCurveTo(0, -12, 0, -18, 6, -18);
    ctx.bezierCurveTo(14, -14, 12, -8, 0, 5);
    ctx.closePath();
  }

  drawBossBar(ctx, boss) {
    ctx.save();
    const barW = Math.min(540, ctx.canvas.width * 0.75);
    const barH = 18;
    const barX = (ctx.canvas.width - barW) / 2;
    const barY = 28;

    // Boss Name & Title
    ctx.textAlign = 'center';
    ctx.font = "bold 13px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ff3344';
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#ff0033';
    ctx.fillText(boss.name.toUpperCase(), ctx.canvas.width / 2, barY - 8);

    ctx.font = "bold 12px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#d1d5db';
    ctx.shadowBlur = 0;
    ctx.fillText(boss.subtitle.toUpperCase(), ctx.canvas.width / 2, barY + 7);

    // Track frame
    ctx.fillStyle = '#1c0d12';
    ctx.fillRect(barX, barY + 15, barW, barH);
    ctx.strokeStyle = '#ff3344';
    ctx.lineWidth = 2;
    ctx.strokeRect(barX, barY + 15, barW, barH);

    // Fill
    const hpPct = Math.max(0, boss.health / boss.maxHealth);
    ctx.fillStyle = '#ff1a35';
    ctx.fillRect(barX + 2, barY + 17, (barW - 4) * hpPct, barH - 4);

    ctx.restore();
  }

  drawMinimap(ctx, mmX, mmY, mmW, mmH, dungeon, currentRoom, player) {
    if (!dungeon || !dungeon.rooms) return;

    let minGX = Infinity, maxGX = -Infinity;
    let minGY = Infinity, maxGY = -Infinity;
    dungeon.rooms.forEach(r => {
      minGX = Math.min(minGX, r.gridX);
      maxGX = Math.max(maxGX, r.gridX);
      minGY = Math.min(minGY, r.gridY);
      maxGY = Math.max(maxGY, r.gridY);
    });

    const spanX = Math.max(1, maxGX - minGX + 1);
    const spanY = Math.max(1, maxGY - minGY + 1);
    const rSize = Math.min(18, Math.floor(Math.min(mmW / (spanX + 1), mmH / (spanY + 1)) * 0.75));
    const spacing = rSize + 6;

    const cX = mmX + mmW / 2 - ((minGX + maxGX) / 2) * spacing;
    const cY = mmY + mmH / 2 - ((minGY + maxGY) / 2) * spacing;

    // Draw corridors
    dungeon.rooms.forEach(r => {
      if (!r.visited) return;
      const rx = cX + r.gridX * spacing;
      const ry = cY + r.gridY * spacing;

      if (r.neighbors['E'] && (r.neighbors['E'].visited || r.visited)) {
        ctx.strokeStyle = '#374151';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(rx, ry);
        ctx.lineTo(cX + r.neighbors['E'].gridX * spacing, ry);
        ctx.stroke();
      }
      if (r.neighbors['S'] && (r.neighbors['S'].visited || r.visited)) {
        ctx.strokeStyle = '#374151';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(rx, ry);
        ctx.lineTo(rx, cY + r.neighbors['S'].gridY * spacing);
        ctx.stroke();
      }
    });

    // Draw rooms
    dungeon.rooms.forEach(r => {
      const rx = cX + r.gridX * spacing;
      const ry = cY + r.gridY * spacing;
      const isCurrent = (r === currentRoom);
      const isAdjacent = Object.values(r.neighbors).some(n => n.visited);

      if (r.visited) {
        ctx.fillStyle = isCurrent ? '#1e3a8a' : '#111827';
        ctx.fillRect(rx - rSize / 2, ry - rSize / 2, rSize, rSize);
        ctx.strokeStyle = isCurrent ? '#00ddff' : (r.cleared ? '#4b5563' : '#ff3344');
        ctx.lineWidth = isCurrent ? 2 : 1;
        ctx.strokeRect(rx - rSize / 2, ry - rSize / 2, rSize, rSize);

        if (r.type === RoomType.BOSS) {
          ctx.font = '8px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('☠️', rx, ry);
        } else if (r.type === RoomType.CHEST) {
          ctx.font = '8px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('📦', rx, ry);
        } else if (r.type === RoomType.ELEVATOR) {
          ctx.font = '9px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🚪', rx, ry);
        }
      } else if (isAdjacent) {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.strokeRect(rx - rSize / 2, ry - rSize / 2, rSize, rSize);
      }

      if (isCurrent && player) {
        const relX = (player.x - r.x) / r.width;
        const relY = (player.y - r.y) / r.height;
        const px = (rx - rSize / 2) + relX * rSize;
        const py = (ry - rSize / 2) + relY * rSize;
        ctx.fillStyle = '#00ddff';
        ctx.beginPath();
        ctx.arc(px, py, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
    });
  }

  // --- OVERLAY: MAIN TITLE MENU ---
  drawMenu(ctx, width, height, dt, onStartGame) {
    this.clearButtons();
    this.updateTitleEmbers(dt, width, height);

    // Dark gradient background
    const bg = ctx.createRadialGradient(width / 2, height / 2, 50, width / 2, height / 2, width * 0.8);
    bg.addColorStop(0, '#151624');
    bg.addColorStop(1, '#06070a');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, width, height);

    // Embers
    this.particles.forEach(p => {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.alpha;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1.0;

    // Card Container
    const cardW = Math.min(620, width * 0.9);
    const cardH = 500;
    const cardX = (width - cardW) / 2;
    const cardY = (height - cardH) / 2;

    ctx.fillStyle = 'rgba(16, 18, 28, 0.95)';
    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, cardH, 8);
    ctx.fill();
    ctx.stroke();

    // Title
    ctx.textAlign = 'center';
    ctx.font = "bold clamp(20px, 4vw, 30px) 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#ff3344';
    ctx.fillText('GUNGEON MYTHOS', width / 2, cardY + 55);

    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#9ca3af';
    ctx.shadowBlur = 0;
    ctx.fillText('A MASMORRA PROCEDURAL DOS DEUSES & O DESAFIO DE FÁFNIR', width / 2, cardY + 85);

    // Lore Box
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(cardX + 24, cardY + 105, cardW - 48, 80);
    ctx.strokeStyle = '#ffaa00';
    ctx.lineWidth = 1;
    ctx.strokeRect(cardX + 24, cardY + 105, cardW - 48, 80);

    ctx.font = "14px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#d1d5db';
    ctx.textAlign = 'left';
    ctx.fillText('• Enfrente masmorras procedurais com combate twin-stick e bullet-hell.', cardX + 36, cardY + 130);
    ctx.fillText('• Derrote os 5 chefes mitológicos até confrontar Fáfnir, o Dragão Ancião!', cardX + 36, cardY + 152);
    ctx.fillText('• O pool de inimigos expande a cada andar (Pistoleiro, SMG, Sniper, Bazuca, Gatling).', cardX + 36, cardY + 174);

    // Controls Box
    ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.fillRect(cardX + 24, cardY + 200, cardW - 48, 170);

    ctx.font = "bold 11px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.textAlign = 'center';
    ctx.fillText('CONTROLES', width / 2, cardY + 225);

    ctx.font = "bold 14px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#fff';
    ctx.textAlign = 'left';
    const col1 = cardX + 44;
    const col2 = cardX + cardW / 2 + 10;

    ctx.fillText('[W, A, S, D] : Movimentar', col1, cardY + 260);
    ctx.fillText('[MOUSE ESQ] : Disparar', col1, cardY + 290);
    ctx.fillText('[R] : Recarregar Arma', col1, cardY + 320);

    ctx.fillText('[ESPAÇO / DIR] : Rolamento (i-frames)', col2, cardY + 260);
    ctx.fillText('[Q] : Blank (Aniquila Balas)', col2, cardY + 290);
    ctx.fillText('[E] : Interagir (Baús / Portais)', col2, cardY + 320);

    // Start Button
    const btnW = 280;
    const btnH = 50;
    const btnX = (width - btnW) / 2;
    const btnY = cardY + 410;
    this.registerButton('start', btnX, btnY, btnW, btnH, 'ENTRAR NA MASMORRA', onStartGame, true);

    this.buttons.forEach(b => this.renderButton(ctx, b));
  }

  // --- OVERLAY: FLOOR TRANSITION SCREEN ---
  drawFloorTransition(ctx, width, height, floorNumber, floorInfo, onContinue) {
    this.clearButtons();

    ctx.fillStyle = 'rgba(6, 7, 12, 0.94)';
    ctx.fillRect(0, 0, width, height);

    const cardW = Math.min(600, width * 0.9);
    const cardH = 440;
    const cardX = (width - cardW) / 2;
    const cardY = (height - cardH) / 2;

    ctx.fillStyle = 'rgba(18, 20, 30, 0.95)';
    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, cardH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.font = "36px sans-serif";
    ctx.fillText('☠️', width / 2, cardY + 50);

    ctx.font = "bold 20px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.fillText(`ANDAR ${floorNumber}`, width / 2, cardY + 95);

    ctx.font = "bold 17px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#9ca3af';
    ctx.fillText(floorInfo ? floorInfo.name : '', width / 2, cardY + 125);

    // Enemy Intel Box
    ctx.fillStyle = 'rgba(255, 51, 68, 0.1)';
    ctx.strokeStyle = 'rgba(255, 51, 68, 0.35)';
    ctx.fillRect(cardX + 24, cardY + 150, cardW - 48, 140);
    ctx.strokeRect(cardX + 24, cardY + 150, cardW - 48, 140);

    ctx.font = "bold 10px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ff3344';
    ctx.textAlign = 'left';
    ctx.fillText('AMEAÇAS DETECTADAS NESTE ANDAR:', cardX + 38, cardY + 175);

    ctx.font = "bold 14px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#f3f4f6';
    if (floorInfo && floorInfo.enemiesDesc) {
      floorInfo.enemiesDesc.forEach((desc, idx) => {
        ctx.fillText(`⚠️ ${desc}`, cardX + 38, cardY + 205 + idx * 24);
      });
    }

    // Boss tease
    ctx.textAlign = 'center';
    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#e5e7eb';
    ctx.fillText(`Guardião do Andar: ${floorInfo ? floorInfo.bossName + ' - ' + floorInfo.bossTitle : ''}`, width / 2, cardY + 325);

    // Button
    const btnW = 200;
    const btnH = 46;
    const btnX = (width - btnW) / 2;
    const btnY = cardY + 360;
    this.registerButton('continue', btnX, btnY, btnW, btnH, 'AVANÇAR', onContinue, true);

    this.buttons.forEach(b => this.renderButton(ctx, b));
  }

  // --- OVERLAY: GAME OVER ---
  drawGameOver(ctx, width, height, stats, onRestart) {
    this.clearButtons();

    ctx.fillStyle = 'rgba(8, 2, 4, 0.94)';
    ctx.fillRect(0, 0, width, height);

    const cardW = Math.min(540, width * 0.9);
    const cardH = 380;
    const cardX = (width - cardW) / 2;
    const cardY = (height - cardH) / 2;

    ctx.fillStyle = 'rgba(24, 10, 14, 0.96)';
    ctx.strokeStyle = '#ff3344';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, cardH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.font = "bold 20px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ff3344';
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#ff0033';
    ctx.fillText('VOCÊ TOMBOU NA MASMORRA', width / 2, cardY + 60);

    ctx.shadowBlur = 0;
    ctx.font = "bold 16px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#d1d5db';
    ctx.textAlign = 'left';
    ctx.fillText(`Andar Atingido: ${stats.floor}`, cardX + 60, cardY + 120);
    ctx.fillText(`Inimigos Eliminados: ${stats.kills}`, cardX + 60, cardY + 155);
    ctx.fillText(`Dano Infligido: ${stats.damage}`, cardX + 60, cardY + 190);
    ctx.fillText(`Arma Final: ${stats.weapon}`, cardX + 60, cardY + 225);

    const btnW = 240;
    const btnH = 46;
    const btnX = (width - btnW) / 2;
    const btnY = cardY + 285;
    this.registerButton('restart', btnX, btnY, btnW, btnH, 'TENTAR NOVAMENTE', onRestart, false);

    this.buttons.forEach(b => this.renderButton(ctx, b));
  }

  // --- OVERLAY: VICTORY ---
  drawVictory(ctx, width, height, stats, onRestart) {
    this.clearButtons();

    ctx.fillStyle = 'rgba(6, 8, 14, 0.94)';
    ctx.fillRect(0, 0, width, height);

    const cardW = Math.min(560, width * 0.9);
    const cardH = 420;
    const cardX = (width - cardW) / 2;
    const cardY = (height - cardH) / 2;

    ctx.fillStyle = 'rgba(18, 24, 38, 0.96)';
    ctx.strokeStyle = '#ffcc00';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(cardX, cardY, cardW, cardH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.textAlign = 'center';
    ctx.font = "36px sans-serif";
    ctx.fillText('👑 🐉 🗡️', width / 2, cardY + 50);

    ctx.font = "bold 22px 'Press Start 2P', monospace";
    ctx.fillStyle = '#ffcc00';
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#ffaa00';
    ctx.fillText('VITÓRIA LENDÁRIA!', width / 2, cardY + 100);

    ctx.shadowBlur = 0;
    ctx.font = "bold 15px 'Rajdhani', sans-serif";
    ctx.fillStyle = '#e5e7eb';
    ctx.fillText('Você derrotou Fáfnir, o Dragão Ancião, e conquistou a Masmorra dos Deuses!', width / 2, cardY + 135);

    ctx.textAlign = 'left';
    ctx.fillText(`Tempo de Incursão: ${stats.time}`, cardX + 60, cardY + 185);
    ctx.fillText(`Total de Vítimas: ${stats.kills}`, cardX + 60, cardY + 220);
    ctx.fillText(`Chefes Mitológicos Derrotados: 5 / 5`, cardX + 60, cardY + 255);

    const btnW = 240;
    const btnH = 46;
    const btnX = (width - btnW) / 2;
    const btnY = cardY + 325;
    this.registerButton('vic-restart', btnX, btnY, btnW, btnH, 'JOGAR OUTRA VEZ', onRestart, true);

    this.buttons.forEach(b => this.renderButton(ctx, b));
  }
}
