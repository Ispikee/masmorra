// Input Manager for keyboard and mouse
class InputManager {
  constructor() {
    this.keys = {};
    this.mouse = {
      screenX: 0,
      screenY: 0,
      worldX: 0,
      worldY: 0,
      leftDown: false,
      rightDown: false,
      justLeftDown: false,
      justRightDown: false,
      justBlankDown: false,
      justInteractDown: false,
      justReloadDown: false
    };

    this.crosshairEl = null;
    this.canvas = null;
  }

  init(canvas) {
    this.canvas = canvas;
    this.crosshairEl = document.getElementById('crosshair');

    window.addEventListener('keydown', (e) => this.onKeyDown(e));
    window.addEventListener('keyup', (e) => this.onKeyUp(e));

    window.addEventListener('mousemove', (e) => this.onMouseMove(e));
    window.addEventListener('mousedown', (e) => this.onMouseDown(e));
    window.addEventListener('mouseup', (e) => this.onMouseUp(e));

    // Disable default context menu so right click can be used for dodge roll!
    window.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  onKeyDown(e) {
    const key = e.key.toLowerCase();
    this.keys[key] = true;

    if (key === 'q') {
      this.mouse.justBlankDown = true;
    }
    if (key === 'e') {
      this.mouse.justInteractDown = true;
    }
    if (key === 'r') {
      this.mouse.justReloadDown = true;
    }
    if (key === ' ' || e.code === 'Space') {
      this.mouse.justRightDown = true; // Space triggers dodge roll
    }
  }

  onKeyUp(e) {
    const key = e.key.toLowerCase();
    this.keys[key] = false;
  }

  onMouseMove(e) {
    this.mouse.screenX = e.clientX;
    this.mouse.screenY = e.clientY;

    if (this.crosshairEl) {
      this.crosshairEl.style.left = `${e.clientX}px`;
      this.crosshairEl.style.top = `${e.clientY}px`;
    }
  }

  onMouseDown(e) {
    if (e.button === 0) {
      this.mouse.leftDown = true;
      this.mouse.justLeftDown = true;
    } else if (e.button === 2) {
      this.mouse.rightDown = true;
      this.mouse.justRightDown = true;
    } else if (e.button === 1) {
      this.mouse.justBlankDown = true;
    }
  }

  onMouseUp(e) {
    if (e.button === 0) {
      this.mouse.leftDown = false;
    } else if (e.button === 2) {
      this.mouse.rightDown = false;
    }
  }

  // Update world coordinates using camera position
  updateWorldMouse(camera) {
    this.mouse.worldX = this.mouse.screenX + camera.x;
    this.mouse.worldY = this.mouse.screenY + camera.y;
  }

  // Call at end of each frame to reset one-frame trigger flags
  resetFrameTriggers() {
    this.mouse.justLeftDown = false;
    this.mouse.justRightDown = false;
    this.mouse.justBlankDown = false;
    this.mouse.justInteractDown = false;
    this.mouse.justReloadDown = false;
  }

  getMovementVector() {
    let dx = 0;
    let dy = 0;

    if (this.keys['w'] || this.keys['arrowup']) dy -= 1;
    if (this.keys['s'] || this.keys['arrowdown']) dy += 1;
    if (this.keys['a'] || this.keys['arrowleft']) dx -= 1;
    if (this.keys['d'] || this.keys['arrowright']) dx += 1;

    // Normalize diagonal movement
    if (dx !== 0 && dy !== 0) {
      const len = Math.hypot(dx, dy);
      dx /= len;
      dy /= len;
    }

    return { dx, dy };
  }
}

export const input = new InputManager();
