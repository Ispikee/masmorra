import { Entity } from './Entity.js';
import { Bullet } from '../combat/Bullet.js';

export const EnemyType = {
  PISTOL: 'pistol',
  SMG: 'smg',
  SNIPER: 'sniper',
  BAZOOKA: 'bazooka',
  GATLING: 'gatling'
};

export class Enemy extends Entity {
  constructor(x, y, type = EnemyType.PISTOL) {
    let radius = 16;
    let health = 45;

    if (type === EnemyType.SMG) { radius = 16; health = 60; }
    if (type === EnemyType.SNIPER) { radius = 15; health = 40; }
    if (type === EnemyType.BAZOOKA) { radius = 20; health = 95; }
    if (type === EnemyType.GATLING) { radius = 24; health = 160; }

    super(x, y, radius, health);
    this.type = type;

    this.shootTimer = 1.0 + Math.random() * 1.5;
    this.stateTimer = 0;
    this.aimAngle = 0;
    this.speed = 100;

    // Telegraphing for Sniper laser
    this.isAimingLaser = false;
    this.laserTimer = 0;

    // Burst firing for SMG
    this.burstRemaining = 0;
    this.burstTimer = 0;

    // Gatling spinup
    this.isSpinningUp = false;
    this.gatlingStreamTimer = 0;
  }

  update(dt, player, bullets, audio, particles) {
    if (this.isDead || !player || player.isDead) return;

    this.stateTimer += dt;
    const distToPlayer = Math.hypot(player.x - this.x, player.y - this.y);
    this.aimAngle = Math.atan2(player.y - this.y, player.x - this.x);

    // AI Behaviors by Enemy Type
    switch (this.type) {
      case EnemyType.PISTOL:
        this.updatePistol(dt, player, distToPlayer, bullets, audio);
        break;
      case EnemyType.SMG:
        this.updateSMG(dt, player, distToPlayer, bullets, audio);
        break;
      case EnemyType.SNIPER:
        this.updateSniper(dt, player, distToPlayer, bullets, audio);
        break;
      case EnemyType.BAZOOKA:
        this.updateBazooka(dt, player, distToPlayer, bullets, audio, particles);
        break;
      case EnemyType.GATLING:
        this.updateGatling(dt, player, distToPlayer, bullets, audio);
        break;
    }

    this.updatePhysics(dt);
  }

  // 1. Pistol Kin: Tactical shooter - approaches, stops to aim/fire, backs off if rushed
  updatePistol(dt, player, dist, bullets, audio) {
    const idealMin = 160;
    const idealMax = 260;

    if (dist > idealMax) {
      // Advance toward player
      this.vx += Math.cos(this.aimAngle) * 110;
      this.vy += Math.sin(this.aimAngle) * 110;
    } else if (dist < idealMin) {
      // Defensive retreat when player rushes
      this.vx -= Math.cos(this.aimAngle) * 90;
      this.vy -= Math.sin(this.aimAngle) * 90;
    } else {
      // Hold position and focus fire (slow micro-step)
      this.vx += Math.cos(this.aimAngle) * 20;
      this.vy += Math.sin(this.aimAngle) * 20;
    }

    this.shootTimer -= dt;
    if (this.shootTimer <= 0) {
      this.shootTimer = 1.1 + Math.random() * 0.5; // Fires every 1.1 - 1.6s
      // Fire single crisp bullet
      const bSpeed = 360;
      bullets.push(new Bullet({
        x: this.x + Math.cos(this.aimAngle) * 16,
        y: this.y + Math.sin(this.aimAngle) * 16,
        vx: Math.cos(this.aimAngle) * bSpeed,
        vy: Math.sin(this.aimAngle) * bSpeed,
        damage: 1,
        radius: 6,
        isPlayer: false,
        color: '#ff3344',
        type: 'enemy_pistol'
      }));
      if (audio) audio.playShoot('pistol');
    }
  }

  // 2. SMG Sprayer: Advances, halts, fires rapid 4-round burst, then repositions
  updateSMG(dt, player, dist, bullets, audio) {
    const idealMin = 140;
    const idealMax = 220;

    if (dist > idealMax) {
      this.vx += Math.cos(this.aimAngle) * 130;
      this.vy += Math.sin(this.aimAngle) * 130;
    } else if (dist < idealMin) {
      this.vx -= Math.cos(this.aimAngle) * 100;
      this.vy -= Math.sin(this.aimAngle) * 100;
    }

    if (this.burstRemaining > 0) {
      // Halts while firing burst
      this.vx *= 0.5;
      this.vy *= 0.5;

      this.burstTimer -= dt;
      if (this.burstTimer <= 0) {
        this.burstTimer = 0.08;
        this.burstRemaining--;
        const spread = (Math.random() - 0.5) * 0.25;
        const angle = this.aimAngle + spread;
        const bSpeed = 440;
        bullets.push(new Bullet({
          x: this.x + Math.cos(angle) * 16,
          y: this.y + Math.sin(angle) * 16,
          vx: Math.cos(angle) * bSpeed,
          vy: Math.sin(angle) * bSpeed,
          damage: 1,
          radius: 5,
          isPlayer: false,
          color: '#ff8800',
          type: 'enemy_smg'
        }));
        if (audio) audio.playShoot('smg');
      }
    } else {
      this.shootTimer -= dt;
      if (this.shootTimer <= 0) {
        this.shootTimer = 1.6 + Math.random() * 0.5;
        this.burstRemaining = 4;
        this.burstTimer = 0.04;
      }
    }
  }

  // 3. Sniper Deadeye: Keeps distance, telegraphs red laser for 1.2s before high velocity shot
  updateSniper(dt, player, dist, bullets, audio) {
    const idealDist = 380;
    if (dist < idealDist) {
      this.vx -= Math.cos(this.aimAngle) * 80;
      this.vy -= Math.sin(this.aimAngle) * 80;
    }

    this.shootTimer -= dt;
    if (this.shootTimer <= 1.2) {
      this.isAimingLaser = true;
    }

    if (this.shootTimer <= 0) {
      this.shootTimer = 3.2;
      this.isAimingLaser = false;

      // High-velocity sniper shot
      const bSpeed = 950;
      bullets.push(new Bullet({
        x: this.x + Math.cos(this.aimAngle) * 20,
        y: this.y + Math.sin(this.aimAngle) * 20,
        vx: Math.cos(this.aimAngle) * bSpeed,
        vy: Math.sin(this.aimAngle) * bSpeed,
        damage: 1,
        radius: 7,
        isPlayer: false,
        color: '#ff0033',
        type: 'sniper'
      }));
      if (audio) audio.playShoot('sniper');
    }
  }

  // 4. Bazooka Bombardier: Fires slow rocket that explodes into 6 shrapnel bullets
  updateBazooka(dt, player, dist, bullets, audio, particles) {
    if (dist > 280) {
      this.vx += Math.cos(this.aimAngle) * 60;
      this.vy += Math.sin(this.aimAngle) * 60;
    }

    this.shootTimer -= dt;
    if (this.shootTimer <= 0) {
      this.shootTimer = 3.0 + Math.random() * 0.8;
      const bSpeed = 240;
      const rocket = new Bullet({
        x: this.x + Math.cos(this.aimAngle) * 20,
        y: this.y + Math.sin(this.aimAngle) * 20,
        vx: Math.cos(this.aimAngle) * bSpeed,
        vy: Math.sin(this.aimAngle) * bSpeed,
        damage: 1,
        radius: 9,
        isPlayer: false,
        color: '#ff4400',
        type: 'enemy_rocket',
        lifetime: 2.2
      });

      // Hook rocket explosion on deletion
      rocket.onDetonate = (spawnList) => {
        if (particles) particles.createExplosion(rocket.x, rocket.y, 50);
        if (audio) audio.playExplosion();
        // Burst 6 shrapnel bullets
        for (let i = 0; i < 6; i++) {
          const sAngle = (i / 6) * Math.PI * 2;
          spawnList.push(new Bullet({
            x: rocket.x,
            y: rocket.y,
            vx: Math.cos(sAngle) * 260,
            vy: Math.sin(sAngle) * 260,
            damage: 1,
            radius: 5,
            isPlayer: false,
            color: '#ff7700',
            type: 'enemy_pistol'
          }));
        }
      };

      bullets.push(rocket);
      if (audio) audio.playShoot('rocket');
    }
  }

  // 5. Heavy Gatling Behemoth: Wind up, sustained bullet hell stream
  updateGatling(dt, player, dist, bullets, audio) {
    // Slowly marches toward player
    this.vx += Math.cos(this.aimAngle) * 45;
    this.vy += Math.sin(this.aimAngle) * 45;

    if (this.gatlingStreamTimer > 0) {
      this.gatlingStreamTimer -= dt;
      if (Math.random() < 0.35) {
        const sweepAngle = this.aimAngle + (Math.sin(this.stateTimer * 6) * 0.4);
        bullets.push(new Bullet({
          x: this.x + Math.cos(sweepAngle) * 24,
          y: this.y + Math.sin(sweepAngle) * 24,
          vx: Math.cos(sweepAngle) * 380,
          vy: Math.sin(sweepAngle) * 380,
          damage: 1,
          radius: 5,
          isPlayer: false,
          color: '#ff2255',
          type: 'enemy_smg'
        }));
        if (audio && Math.random() < 0.3) audio.playShoot('smg');
      }
    } else {
      this.shootTimer -= dt;
      if (this.shootTimer <= 0) {
        this.shootTimer = 3.5;
        this.gatlingStreamTimer = 1.8; // Fires for 1.8 seconds!
      }
    }
  }

  render(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);

    // Hit flash
    if (this.flashTimer > 0) {
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(0, 0, this.radius + 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      return;
    }

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.ellipse(0, this.radius - 2, this.radius * 0.9, this.radius * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();

    const isFacingLeft = Math.cos(this.aimAngle) < 0;

    // Body rendering by enemy type
    switch (this.type) {
      case EnemyType.PISTOL:
        // Bullet kin shape (bronze bullet shell with eyes)
        ctx.fillStyle = '#d97706';
        ctx.beginPath();
        ctx.arc(0, -4, 12, Math.PI, 0); // Rounded head
        ctx.lineTo(12, 10);
        ctx.lineTo(-12, 10);
        ctx.closePath();
        ctx.fill();

        // White rim
        ctx.fillStyle = '#fef3c7';
        ctx.fillRect(-12, 8, 24, 4);

        // Big cartoon eyes
        ctx.fillStyle = '#ffffff';
        const pEyeX = isFacingLeft ? -4 : 2;
        ctx.fillRect(pEyeX, -6, 4, 6);
        ctx.fillRect(pEyeX + (isFacingLeft ? -5 : 5), -6, 4, 6);
        ctx.fillStyle = '#000';
        ctx.fillRect(pEyeX + (isFacingLeft ? 0 : 2), -4, 2, 3);
        ctx.fillRect(pEyeX + (isFacingLeft ? -5 : 7), -4, 2, 3);
        break;

      case EnemyType.SMG:
        // Blue military bullet kin with bandana
        ctx.fillStyle = '#1e3a8a';
        ctx.beginPath();
        ctx.arc(0, -4, 13, Math.PI, 0);
        ctx.lineTo(13, 10);
        ctx.lineTo(-13, 10);
        ctx.closePath();
        ctx.fill();

        // Red bandana
        ctx.fillStyle = '#dc2626';
        ctx.fillRect(-13, -7, 26, 5);

        // Angry eyes
        ctx.fillStyle = '#fff';
        const sEyeX = isFacingLeft ? -3 : 2;
        ctx.fillRect(sEyeX, -2, 4, 4);
        ctx.fillRect(sEyeX + (isFacingLeft ? -5 : 5), -2, 4, 4);
        break;

      case EnemyType.SNIPER:
        // Crimson hooded sniper
        ctx.fillStyle = '#7f1d1d';
        ctx.beginPath();
        ctx.arc(0, -2, 13, 0, Math.PI * 2);
        ctx.fill();

        // Monocle / Glowing crosshair eye
        ctx.fillStyle = '#00ffff';
        ctx.shadowBlur = 6;
        ctx.shadowColor = '#00ffff';
        ctx.beginPath();
        ctx.arc(isFacingLeft ? -5 : 5, -3, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        break;

      case EnemyType.BAZOOKA:
        // Chunky military green tank kin
        ctx.fillStyle = '#166534';
        ctx.fillRect(-16, -14, 32, 26);
        // Heavy armor plates
        ctx.fillStyle = '#14532d';
        ctx.fillRect(-18, -4, 36, 10);
        // Helmet visor
        ctx.fillStyle = '#facc15';
        ctx.fillRect(-8, -10, 16, 4);
        break;

      case EnemyType.GATLING:
        // Huge steel juggernaut
        ctx.fillStyle = '#374151';
        ctx.beginPath();
        ctx.arc(0, 0, 20, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#1f2937';
        ctx.fillRect(-14, -6, 28, 14);

        // Menacing red visor slit
        ctx.fillStyle = '#ff0033';
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#ff0033';
        ctx.fillRect(-10, -6, 20, 4);
        ctx.shadowBlur = 0;
        break;
    }

    // Health bar above enemy head (if damaged)
    if (this.health < this.maxHealth) {
      const pct = this.health / this.maxHealth;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(-16, -this.radius - 12, 32, 5);
      ctx.fillStyle = '#ff3344';
      ctx.fillRect(-15, -this.radius - 11, 30 * pct, 3);
    }

    ctx.restore();

    // Render Sniper Laser Telegraph in World coordinates
    if (this.type === EnemyType.SNIPER && this.isAimingLaser) {
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(this.x, this.y);
      ctx.lineTo(this.x + Math.cos(this.aimAngle) * 600, this.y + Math.sin(this.aimAngle) * 600);
      ctx.strokeStyle = 'rgba(255, 0, 50, 0.65)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 6]);
      ctx.shadowBlur = 6;
      ctx.shadowColor = '#ff0033';
      ctx.stroke();
      ctx.restore();
    }
  }
}

// Spawner helper according to floor rules
export function spawnEnemiesForFloor(floorNumber, room) {
  const enemies = [];
  const padding = 120;
  const count = 3 + floorNumber; // 4 enemies on floor 1, up to 8 on floor 5

  const availableTypes = [EnemyType.PISTOL];
  if (floorNumber >= 2) availableTypes.push(EnemyType.SMG, EnemyType.SNIPER);
  if (floorNumber >= 3) availableTypes.push(EnemyType.BAZOOKA);
  if (floorNumber >= 4) availableTypes.push(EnemyType.GATLING);

  for (let i = 0; i < count; i++) {
    const rx = room.x + padding + Math.random() * (room.width - padding * 2);
    const ry = room.y + padding + Math.random() * (room.height - padding * 2);

    // Pick enemy from available pool for this floor
    const type = availableTypes[Math.floor(Math.random() * availableTypes.length)];
    enemies.push(new Enemy(rx, ry, type));
  }

  return enemies;
}
