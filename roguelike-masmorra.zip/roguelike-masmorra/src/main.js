import { audio } from './core/Audio.js';
import { input } from './core/Input.js';
import { Camera } from './core/Camera.js';
import { DungeonGenerator } from './dungeon/DungeonGenerator.js';
import { DungeonRenderer } from './dungeon/TileMap.js';
import { RoomType } from './dungeon/Room.js';
import { Player } from './entities/Player.js';
import { spawnEnemiesForFloor } from './entities/Enemy.js';
import { Boss } from './entities/Bosses.js';
import { ParticleSystem } from './effects/ParticleSystem.js';
import { CanvasUI } from './ui/CanvasUI.js';
import { WeaponTypes } from './combat/Weapons.js';

// Floor Names and Lore Data
const FLOOR_INFO = {
  1: {
    name: 'As Catacumbas de Creta',
    bossName: 'Minotauro de Creta',
    bossTitle: 'O Guardião do Labirinto',
    enemiesDesc: ['Pistoleiro (Pistol Kin) - Disparos pontuais']
  },
  2: {
    name: 'As Tumbas de Anúbis',
    bossName: 'Anúbis',
    bossTitle: 'O Juiz das Almas',
    enemiesDesc: [
      'Pistoleiro (Pistol Kin)',
      'Atirador de Metralhadora (SMG Kin) - Rajadas rápidas',
      'Franco-Atirador (Sniper Deadeye) - Mira laser telegrafada'
    ]
  },
  3: {
    name: 'A Fortaleza de Fenrir',
    bossName: 'Fenrir',
    bossTitle: 'O Devorador de Deuses',
    enemiesDesc: [
      'Pistoleiro, Metralhadora & Sniper',
      'Bombardeiro de Bazuca (Rocket Kin) - Mísseis que explodem em estilhaços'
    ]
  },
  4: {
    name: 'O Sanctum de Hades',
    bossName: 'Hades',
    bossTitle: 'O Lorde do Submundo',
    enemiesDesc: [
      'Todas as tropas anteriores',
      'Bruto de Gatling (Heavy Behemoth) - Chuva contínua de balas'
    ]
  },
  5: {
    name: 'O Covil Ancestral de Fáfnir',
    bossName: 'Fáfnir, o Dragão Ancião',
    bossTitle: 'Senhor do Ouro e do Caos',
    enemiesDesc: [
      'Tropas de Elite combinadas em força total',
      'O DRAGÃO LENDÁRIO aguarda no final!'
    ]
  }
};

class Game {
  constructor() {
    this.canvas = document.getElementById('game-canvas');
    this.ctx = this.canvas.getContext('2d');

    this.ui = new CanvasUI();
    this.dungeonRenderer = new DungeonRenderer();
    this.dungeonGen = new DungeonGenerator();
    this.particles = new ParticleSystem();

    this.camera = null;
    this.player = null;
    this.dungeon = null;
    this.currentRoom = null;
    this.activeBoss = null;

    this.bullets = [];
    this.currentFloor = 1;
    this.maxFloors = 5;

    // Statistics
    this.totalKills = 0;
    this.totalDamageDealt = 0;
    this.startTime = 0;

    // Game States: 'MENU', 'PLAYING', 'FLOOR_TRANSITION', 'GAMEOVER', 'VICTORY'
    this.state = 'MENU';
    this.interactionPrompt = null;

    this.lastTime = 0;
  }

  init() {
    this.resizeCanvas();
    window.addEventListener('resize', () => this.resizeCanvas());

    this.camera = new Camera(this.canvas.width, this.canvas.height);
    input.init(this.canvas);

    // Canvas click event for UI buttons
    window.addEventListener('click', (e) => {
      audio.ensureContext();
      this.ui.handleClick(e.clientX, e.clientY, audio);
    });

    this.lastTime = performance.now();
    requestAnimationFrame((t) => this.loop(t));
  }

  resizeCanvas() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    if (this.camera) {
      this.camera.resize(this.canvas.width, this.canvas.height);
    }
  }

  startRun() {
    this.currentFloor = 1;
    this.totalKills = 0;
    this.totalDamageDealt = 0;
    this.startTime = Date.now();

    this.loadFloor(1);
    this.state = 'FLOOR_TRANSITION';
    audio.playBossRoar();
  }

  loadFloor(floorNumber) {
    this.currentFloor = floorNumber;
    this.bullets = [];
    this.activeBoss = null;
    this.bossDefeated = false;

    // Procedural dungeon generation
    this.dungeon = this.dungeonGen.generate(floorNumber);
    const startRoom = this.dungeon.startRoom;

    // Spawn player in center of start room
    const playerX = startRoom.x + startRoom.width / 2;
    const playerY = startRoom.y + startRoom.height / 2;

    if (!this.player) {
      this.player = new Player(playerX, playerY);
    } else {
      // Retain weapons, refill blanks to 2 if depleted, restore 2 HP
      this.player.x = playerX;
      this.player.y = playerY;
      this.player.vx = 0;
      this.player.vy = 0;
      this.player.blanks = Math.max(2, this.player.blanks);
      this.player.health = Math.min(this.player.maxHealth, this.player.health + 2);
    }

    this.currentRoom = startRoom;
    this.currentRoom.visited = true;

    // Prepare weapon drop for chest room
    if (this.dungeon.chestRoom && this.dungeon.chestRoom.chest) {
      const chest = this.dungeon.chestRoom.chest;
      const weaponPool = [
        WeaponTypes.SHOTGUN,
        WeaponTypes.AK47,
        WeaponTypes.SNIPER,
        WeaponTypes.RPG,
        WeaponTypes.PLASMA
      ];
      const unowned = weaponPool.filter(w => !this.player.weapons.some(pw => pw.id === w.id));
      chest.weaponDrop = unowned.length > 0
        ? unowned[Math.floor(Math.random() * unowned.length)]
        : weaponPool[Math.floor(Math.random() * weaponPool.length)];
    }
  }

  loop(currentTime) {
    const dt = Math.min(0.1, (currentTime - this.lastTime) / 1000);
    this.lastTime = currentTime;

    // Update UI button hover states
    this.ui.handleMouseMove(input.mouse.screenX, input.mouse.screenY);
    this.ui.updateToast(dt);

    if (this.state === 'PLAYING') {
      this.update(dt);
    }

    this.render(dt);

    requestAnimationFrame((t) => this.loop(t));
  }

  update(dt) {
    // 1. Camera & Mouse Coordinates
    this.camera.update(this.player, input.mouse.screenX, input.mouse.screenY, dt);
    input.updateWorldMouse(this.camera);

    // 2. Systems
    this.dungeonRenderer.update(dt);
    this.particles.update(dt);

    // 3. Player
    this.player.update(dt, input, audio, this.particles, this.camera);
    this.player.resolveEnvironmentCollisions(this.currentRoom, this.dungeon.rooms);

    // 4. Room Tracking
    this.updateRoomTracking();

    // 5. Shooting
    if (input.mouse.leftDown && !this.player.isRolling) {
      const newBullets = this.player.activeWeapon.shoot(
        this.player.x,
        this.player.y,
        input.mouse.worldX,
        input.mouse.worldY,
        audio,
        this.camera
      );

      if (newBullets.length > 0) {
        this.bullets.push(...newBullets);
        this.particles.createMuzzleFlash(this.player.x, this.player.y, this.player.aimAngle);
        this.particles.createShell(this.player.x, this.player.y, this.player.aimAngle);
      }
    }

    // 6. Blank (Q / Middle click)
    if (input.mouse.justBlankDown) {
      const roomEnemies = this.currentRoom ? this.currentRoom.enemies : [];
      if (this.activeBoss && !this.activeBoss.isDead) roomEnemies.push(this.activeBoss);
      this.player.triggerBlank(audio, this.particles, this.camera, this.bullets, roomEnemies);
    }

    // 7. Enemies in Room
    if (this.currentRoom && this.currentRoom.enemies.length > 0) {
      // Physical separation: prevent enemies from stacking on each other or on player
      for (let i = 0; i < this.currentRoom.enemies.length; i++) {
        const e1 = this.currentRoom.enemies[i];
        for (let j = i + 1; j < this.currentRoom.enemies.length; j++) {
          e1.resolveSeparation(this.currentRoom.enemies[j], 6);
        }
        e1.resolveSeparation(this.player, 8);
      }

      for (let i = this.currentRoom.enemies.length - 1; i >= 0; i--) {
        const enemy = this.currentRoom.enemies[i];
        enemy.update(dt, this.player, this.bullets, audio, this.particles);
        enemy.resolveEnvironmentCollisions(this.currentRoom, this.dungeon.rooms);

        if (enemy.isDead) {
          this.totalKills++;
          this.particles.createBlood(enemy.x, enemy.y, 16, '#ff3344');
          this.particles.createExplosion(enemy.x, enemy.y, 25);
          if (audio) audio.playHit();
          this.currentRoom.enemies.splice(i, 1);

          if (Math.random() < 0.45) {
            this.player.coins += 2 + Math.floor(Math.random() * 3);
          }
          if (Math.random() < 0.15 && this.player.health < this.player.maxHealth) {
            this.player.health = Math.min(this.player.maxHealth, this.player.health + 1);
            this.ui.showToast('Coração Recuperado! (+1 HP)');
          }
        }
      }

      if (this.currentRoom.enemies.length === 0 && !this.currentRoom.cleared) {
        this.currentRoom.cleared = true;
        this.currentRoom.unlockDoors();
        this.ui.showToast('SALA LIMPA!');
        audio.playVictory();
      }
    }

    // 8. Boss
    if (this.activeBoss && !this.activeBoss.isDead) {
      this.activeBoss.update(dt, this.player, this.bullets, audio, this.particles, this.camera);
      this.activeBoss.resolveEnvironmentCollisions(this.currentRoom, this.dungeon.rooms);

      // PHYSICAL COLLISION: Boss CANNOT sit on top of the player!
      const bdx = this.player.x - this.activeBoss.x;
      const bdy = this.player.y - this.activeBoss.y;
      const bdist = Math.hypot(bdx, bdy);
      const minBossDist = this.player.radius + this.activeBoss.radius + 14;

      if (bdist < minBossDist && bdist > 0.001) {
        const overlap = minBossDist - bdist;
        const nx = bdx / bdist;
        const ny = bdy / bdist;

        // Push player away strongly from boss
        this.player.x += nx * overlap;
        this.player.y += ny * overlap;
        this.activeBoss.x -= nx * (overlap * 0.2);
        this.activeBoss.y -= ny * (overlap * 0.2);

        // Contact damage & knockback if player is not rolling and not invulnerable
        if (!this.player.isRolling && !this.player.isInvulnerable) {
          this.player.takeDamage(1);
          audio.playPlayerHurt();
          this.camera.addTrauma(0.45);
          this.particles.createBlood(this.player.x, this.player.y, 10);
          this.player.vx += nx * 380;
          this.player.vy += ny * 380;
        }
      }

      if (this.activeBoss.health <= 0) {
        this.handleBossDefeat();
      }
    }

    // 9. Chest, Portal & Elevator
    if (this.currentRoom) {
      if (this.currentRoom.chest) this.currentRoom.chest.update(dt);
      if (this.currentRoom.portal) this.currentRoom.portal.update(dt);
      if (this.currentRoom.elevator) this.currentRoom.elevator.update(dt);
    }

    // 10. Bullets & Collisions
    this.updateBullets(dt);

    // 11. Interactions
    this.updateInteractions();

    // 12. Player Death
    if (this.player.isDead) {
      this.state = 'GAMEOVER';
      audio.playPlayerHurt();
    }

    input.resetFrameTriggers();
  }

  updateRoomTracking() {
    for (const room of this.dungeon.rooms) {
      if (room.contains(this.player.x, this.player.y)) {
        if (this.currentRoom !== room) {
          this.currentRoom = room;
          room.visited = true;

          if (!room.cleared) {
            room.lockDoors();

            if (room.type === RoomType.COMBAT) {
              room.enemies = spawnEnemiesForFloor(this.currentFloor, room);
            } else if (room.type === RoomType.BOSS) {
              if (!this.activeBoss) {
                this.activeBoss = new Boss(
                  room.x + room.width / 2,
                  room.y + room.height / 2,
                  this.currentFloor
                );
                audio.playBossRoar();
                this.camera.addTrauma(0.5);
              }
            }
          }
        }
        break;
      }
    }
  }

  updateBullets(dt) {
    const spawnedBullets = [];

    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.update(dt, this.particles);

      if (b.markedForDeletion) {
        if (b.onDetonate) b.onDetonate(spawnedBullets);
        this.bullets.splice(i, 1);
        continue;
      }

      // Pillar collision
      if (this.currentRoom && this.currentRoom.pillars) {
        let hitPillar = false;
        for (const p of this.currentRoom.pillars) {
          const dist = Math.hypot(b.x - p.x, b.y - p.y);
          if (dist < b.radius + p.radius) {
            hitPillar = true;
            break;
          }
        }

        if (hitPillar) {
          this.particles.createHitSparks(b.x, b.y, b.color);
          if (b.onDetonate) b.onDetonate(spawnedBullets);
          this.bullets.splice(i, 1);
          continue;
        }
      }

      // Wall collision
      if (this.currentRoom) {
        const minX = this.currentRoom.x;
        const maxX = this.currentRoom.x + this.currentRoom.width;
        const minY = this.currentRoom.y;
        const maxY = this.currentRoom.y + this.currentRoom.height;

        if (b.x < minX || b.x > maxX || b.y < minY || b.y > maxY) {
          if (b.bounces > 0) {
            b.bounces--;
            if (b.x < minX || b.x > maxX) b.vx = -b.vx;
            if (b.y < minY || b.y > maxY) b.vy = -b.vy;
            this.particles.createHitSparks(b.x, b.y, b.color);
          } else {
            this.particles.createHitSparks(b.x, b.y, b.color);
            if (b.onDetonate) b.onDetonate(spawnedBullets);
            this.bullets.splice(i, 1);
            continue;
          }
        }
      }

      // Player bullets vs Enemies & Boss
      if (b.isPlayer) {
        let hitTarget = false;

        if (this.currentRoom && this.currentRoom.enemies) {
          for (const enemy of this.currentRoom.enemies) {
            if (enemy.isDead) continue;
            const dist = Math.hypot(b.x - enemy.x, b.y - enemy.y);
            if (dist < b.radius + enemy.radius) {
              const isCrit = Math.random() < 0.2;
              const actualDmg = isCrit ? Math.round(b.damage * 1.6) : b.damage;
              enemy.takeDamage(actualDmg);

              this.totalDamageDealt += actualDmg;
              this.particles.createBlood(b.x, b.y, 8);
              this.particles.createDamageText(b.x, b.y, actualDmg, isCrit);
              if (audio) audio.playHit();

              hitTarget = true;
              break;
            }
          }
        }

        if (!hitTarget && this.activeBoss && !this.activeBoss.isDead) {
          const dist = Math.hypot(b.x - this.activeBoss.x, b.y - this.activeBoss.y);
          if (dist < b.radius + this.activeBoss.radius) {
            const isCrit = Math.random() < 0.15;
            const actualDmg = isCrit ? Math.round(b.damage * 1.5) : b.damage;
            this.activeBoss.takeDamage(actualDmg);

            this.totalDamageDealt += actualDmg;
            this.particles.createHitSparks(b.x, b.y, '#ffaa00');
            this.particles.createDamageText(b.x, b.y, actualDmg, isCrit);
            if (audio) audio.playHit();

            if (this.activeBoss.health <= 0) {
              this.handleBossDefeat();
            }

            hitTarget = true;
          }
        }

        if (hitTarget) {
          b.pierce--;
          if (b.pierce <= 0) {
            if (b.onDetonate) b.onDetonate(spawnedBullets);
            this.bullets.splice(i, 1);
            continue;
          }
        }
      } else {
        // Enemy bullets vs Player
        const dist = Math.hypot(b.x - this.player.x, b.y - this.player.y);
        if (dist < b.radius + this.player.radius) {
          if (!this.player.isRolling && !this.player.isInvulnerable) {
            this.player.takeDamage(b.damage);
            audio.playPlayerHurt();
            this.camera.addTrauma(0.5);
            this.particles.createBlood(this.player.x, this.player.y, 14);

            this.bullets.splice(i, 1);
            continue;
          }
        }
      }
    }

    if (spawnedBullets.length > 0) {
      this.bullets.push(...spawnedBullets);
    }
  }

  handleBossDefeat() {
    if (this.bossDefeated) return;
    this.bossDefeated = true;
    if (this.activeBoss) this.activeBoss.isDead = true;
    this.totalKills++;

    const bX = this.activeBoss ? this.activeBoss.x : this.player.x;
    const bY = this.activeBoss ? this.activeBoss.y : this.player.y;

    this.particles.createExplosion(bX, bY, 160);
    this.particles.createShockwave(bX, bY, 600, '#ffd700', 900);
    audio.playVictory();

    const bName = this.activeBoss ? this.activeBoss.name.toUpperCase() : 'CHEFE';
    this.ui.showToast(`O ${bName} FOI DERROTADO!`, 3.0);

    // Reward loot: coins and full heart recovery
    this.player.coins += 40;
    this.player.health = Math.min(this.player.maxHealth, this.player.health + 2);

    // UNLOCK ALL DOORS in boss room AND unlock the BossExitGate leading into Elevator Room!
    if (this.currentRoom) {
      this.currentRoom.cleared = true;
      this.currentRoom.doors.forEach(d => d.isLocked = false);
    }
    if (this.dungeon && this.dungeon.bossRoom) {
      this.dungeon.bossRoom.cleared = true;
      this.dungeon.bossRoom.doors.forEach(d => d.isLocked = false);
    }

    // Reveal Elevator Room on minimap
    if (this.dungeon && this.dungeon.elevatorRoom) {
      this.dungeon.elevatorRoom.visited = true;
    }

    // Spawn an extra Backup Portal right on the floor too
    if (this.currentRoom) {
      this.currentRoom.portal = new Portal(bX, bY);
      this.currentRoom.portal.active = true;
    }

    setTimeout(() => {
      this.ui.showToast('PORTÃO DO ELEVADOR ABERTO! SIGA PARA A SALA DE SAÍDA!', 4.0);
    }, 1800);
  }

  updateInteractions() {
    this.interactionPrompt = null;

    // 1. Chest Interaction
    if (this.currentRoom && this.currentRoom.chest && !this.currentRoom.chest.isOpen) {
      const chest = this.currentRoom.chest;
      const dist = Math.hypot(this.player.x - chest.x, this.player.y - chest.y);

      if (dist < 64) {
        this.interactionPrompt = 'Pressione [E] para Abrir Baú';

        if (input.mouse.justInteractDown) {
          chest.isOpen = true;
          audio.playChestOpen();
          this.particles.createExplosion(chest.x, chest.y, 35);

          if (chest.weaponDrop) {
            this.player.equipWeapon(chest.weaponDrop);
            this.ui.showToast(`ARMA OBTIDA: ${chest.weaponDrop.name.toUpperCase()}!`);
          }
        }
      }
    }

    // 2. Elevator Chamber Interaction (The dedicated Exit Chamber!)
    let elevatorObj = null;
    if (this.currentRoom && this.currentRoom.elevator) {
      elevatorObj = this.currentRoom.elevator;
    } else if (this.dungeon && this.dungeon.elevatorRoom && this.dungeon.elevatorRoom.elevator) {
      elevatorObj = this.dungeon.elevatorRoom.elevator;
    }

    if (elevatorObj && this.bossDefeated) {
      const dist = Math.hypot(this.player.x - elevatorObj.x, this.player.y - elevatorObj.y);
      const inElevatorRoom = (this.currentRoom && this.currentRoom.type === RoomType.ELEVATOR);

      if (dist < 110 || inElevatorRoom) {
        if (this.currentFloor === this.maxFloors) {
          this.interactionPrompt = 'Pressione [E] ou Pise no Elevador para a Vitória!';
        } else {
          this.interactionPrompt = `Pressione [E] ou Pise no Elevador para Descer ao Andar ${this.currentFloor + 1}`;
        }

        // Stepping onto elevator platform (dist < 65) OR pressing E triggers descent!
        if (input.mouse.justInteractDown || dist < 65) {
          if (this.currentFloor === this.maxFloors) {
            this.state = 'VICTORY';
            audio.playVictory();
          } else {
            audio.playChestOpen();
            this.nextFloor();
          }
        }
      }
    }

    // 3. Backup Portal Interaction
    if (this.currentRoom && this.currentRoom.portal && this.currentRoom.portal.active) {
      const portal = this.currentRoom.portal;
      const dist = Math.hypot(this.player.x - portal.x, this.player.y - portal.y);

      if (dist < 85) {
        if (this.currentFloor === this.maxFloors) {
          this.interactionPrompt = 'Pressione [E] ou Pise no Portal para a Vitória!';
        } else {
          this.interactionPrompt = `Pressione [E] ou Pise no Portal para Ir ao Andar ${this.currentFloor + 1}`;
        }

        if (input.mouse.justInteractDown || dist < 46) {
          if (this.currentFloor === this.maxFloors) {
            this.state = 'VICTORY';
            audio.playVictory();
          } else {
            this.nextFloor();
          }
        }
      }
    }
  }

  nextFloor() {
    const nextF = this.currentFloor + 1;
    this.loadFloor(nextF);
    this.state = 'FLOOR_TRANSITION';
    audio.playBossRoar();
  }

  render(dt) {
    const ctx = this.ctx;
    const width = this.canvas.width;
    const height = this.canvas.height;

    ctx.clearRect(0, 0, width, height);

    // 1. STATE: MENU
    if (this.state === 'MENU') {
      this.ui.drawMenu(ctx, width, height, dt, () => this.startRun());
      this.ui.drawCrosshair(ctx, input.mouse.screenX, input.mouse.screenY, false);
      return;
    }

    // 2. IN-GAME WORLD RENDERING
    ctx.save();
    const offset = this.camera.getRenderOffset();
    ctx.translate(-offset.x, -offset.y);

    if (this.dungeon) {
      this.dungeonRenderer.render(ctx, this.dungeon, this.currentFloor, this.player);
    }

    this.particles.render(ctx);

    if (this.currentRoom && this.currentRoom.enemies) {
      this.currentRoom.enemies.forEach(e => e.render(ctx));
    }

    if (this.activeBoss && !this.activeBoss.isDead) {
      this.activeBoss.render(ctx);
    }

    if (this.player) {
      this.player.render(ctx);
    }

    this.bullets.forEach(b => b.render(ctx));
    ctx.restore();

    // 3. IN-GAME HUD
    if (this.state === 'PLAYING') {
      const floorInfo = FLOOR_INFO[this.currentFloor];
      this.ui.drawHUD(
        ctx,
        this.player,
        this.currentFloor,
        floorInfo,
        this.activeBoss,
        this.dungeon,
        this.currentRoom,
        this.interactionPrompt
      );
    }

    // 4. STATE: FLOOR TRANSITION OVERLAY
    if (this.state === 'FLOOR_TRANSITION') {
      const floorInfo = FLOOR_INFO[this.currentFloor];
      this.ui.drawFloorTransition(ctx, width, height, this.currentFloor, floorInfo, () => {
        this.state = 'PLAYING';
      });
    }

    // 5. STATE: GAME OVER OVERLAY
    if (this.state === 'GAMEOVER') {
      this.ui.drawGameOver(
        ctx,
        width,
        height,
        {
          floor: this.currentFloor,
          kills: this.totalKills,
          damage: this.totalDamageDealt,
          weapon: this.player ? this.player.activeWeapon.name : 'Pistola'
        },
        () => this.startRun()
      );
    }

    // 6. STATE: VICTORY OVERLAY
    if (this.state === 'VICTORY') {
      const elapsedSeconds = Math.floor((Date.now() - this.startTime) / 1000);
      const mins = String(Math.floor(elapsedSeconds / 60)).padStart(2, '0');
      const secs = String(elapsedSeconds % 60).padStart(2, '0');

      this.ui.drawVictory(
        ctx,
        width,
        height,
        {
          time: `${mins}:${secs}`,
          kills: this.totalKills
        },
        () => this.startRun()
      );
    }

    // 7. Tactical Crosshair
    this.ui.drawCrosshair(ctx, input.mouse.screenX, input.mouse.screenY, input.mouse.leftDown);
  }
}

window.addEventListener('DOMContentLoaded', () => {
  const game = new Game();
  game.init();
});
