// Automated verification script for dungeon generation and progression rules
import { DungeonGenerator } from '../src/dungeon/DungeonGenerator.js';
import { spawnEnemiesForFloor, EnemyType } from '../src/entities/Enemy.js';
import { Boss } from '../src/entities/Bosses.js';
import { WeaponTypes, Weapon } from '../src/combat/Weapons.js';

console.log('--- RUNNING ROGUELIKE VERIFICATION SUITE ---');

const gen = new DungeonGenerator();

// 1. Verify Dungeon Generation for Floors 1 to 5
for (let floor = 1; floor <= 5; floor++) {
  const dungeon = gen.generate(floor);
  console.log(`Floor ${floor}: Generated ${dungeon.rooms.length} rooms.`);

  if (!dungeon.startRoom) throw new Error(`Floor ${floor} missing Start Room`);
  if (!dungeon.bossRoom) throw new Error(`Floor ${floor} missing Boss Room`);
  if (!dungeon.chestRoom) throw new Error(`Floor ${floor} missing Chest Room`);

  // Verify Graph Reachability (BFS)
  const visited = new Set();
  const queue = [dungeon.startRoom];
  visited.add(dungeon.startRoom);

  while (queue.length > 0) {
    const current = queue.shift();
    for (const neighbor of Object.values(current.neighbors)) {
      if (!visited.has(neighbor)) {
        visited.add(neighbor);
        queue.push(neighbor);
      }
    }
  }

  if (visited.size !== dungeon.rooms.length) {
    throw new Error(`Floor ${floor} has disconnected rooms! Reachable: ${visited.size}, Total: ${dungeon.rooms.length}`);
  }
}
console.log('✔ Procedural Dungeon generation & connectivity passed for all 5 floors.');

// 2. Verify Enemy Progression per Floor
for (let floor = 1; floor <= 5; floor++) {
  const dummyRoom = { x: 0, y: 0, width: 800, height: 600 };
  const enemies = [];
  // Sample multiple spawns to get full enemy distribution
  for (let s = 0; s < 50; s++) {
    enemies.push(...spawnEnemiesForFloor(floor, dummyRoom));
  }

  const typesFound = new Set(enemies.map(e => e.type));
  console.log(`Floor ${floor} Enemy Types:`, Array.from(typesFound));

  if (floor === 1) {
    if (typesFound.size !== 1 || !typesFound.has(EnemyType.PISTOL)) {
      throw new Error(`Floor 1 should ONLY have Pistol enemies, found: ${Array.from(typesFound)}`);
    }
  } else if (floor === 2) {
    if (!typesFound.has(EnemyType.PISTOL) || !typesFound.has(EnemyType.SMG) || !typesFound.has(EnemyType.SNIPER)) {
      throw new Error(`Floor 2 missing required enemies: ${Array.from(typesFound)}`);
    }
    if (typesFound.has(EnemyType.BAZOOKA) || typesFound.has(EnemyType.GATLING)) {
      throw new Error(`Floor 2 contains higher-tier enemies prematurely!`);
    }
  } else if (floor === 3) {
    if (!typesFound.has(EnemyType.BAZOOKA)) {
      throw new Error(`Floor 3 missing Bazooka enemy!`);
    }
    if (typesFound.has(EnemyType.GATLING)) {
      throw new Error(`Floor 3 contains Gatling prematurely!`);
    }
  } else if (floor >= 4) {
    if (!typesFound.has(EnemyType.GATLING)) {
      throw new Error(`Floor ${floor} missing Gatling enemy!`);
    }
  }
}
console.log('✔ Floor enemy scaling & progression adheres strictly to user rules.');

// 3. Verify Mythological Bosses
const bosses = [
  new Boss(0, 0, 1),
  new Boss(0, 0, 2),
  new Boss(0, 0, 3),
  new Boss(0, 0, 4),
  new Boss(0, 0, 5)
];

bosses.forEach((boss, idx) => {
  const floor = idx + 1;
  console.log(`Floor ${floor} Boss: "${boss.name}" (${boss.subtitle}), HP: ${boss.maxHealth}`);
  if (boss.maxHealth <= 0) throw new Error(`Invalid boss health on floor ${floor}`);
});
console.log('✔ All 5 Mythological Bosses (including Fáfnir Dragon on Floor 5) verified.');

// 4. Verify Weapons
const weapons = Object.values(WeaponTypes).map(def => new Weapon(def));
weapons.forEach(w => {
  if (w.currentClip <= 0 || w.def.damage <= 0) {
    throw new Error(`Invalid weapon definition: ${w.name}`);
  }
  console.log(`Weapon: ${w.name} [Clip: ${w.currentClip}, Dmg: ${w.def.damage}, Sound: ${w.def.sound}]`);
});
console.log('✔ All weapons verified.');

console.log('--- ALL VERIFICATIONS PASSED SUCCESSFULLY! ---');
